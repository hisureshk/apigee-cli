package com.prudential.apigee.config;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ImportConfig {

	@Value("${to.url}")
	private String toURL;

	@Value("${to.userid}")
	private String toUserId;

	@Value("${to.password}")
	private String toPassword;

	@Value("${to.org}")
	private String toOrg;

	@Value("${to.env}")
	private String toEnv;

	@Value("${to.resource}")
	private String toResource;

	@Value("${export.dir}")
	private String exportDir;

	@Value("${to.deploy}")
	private boolean toDeploy;

	public String getToURL() {
		return toURL;
	}

	public void setToURL(String toURL) {
		this.toURL = toURL;
	}

	public String getToUserId() {
		return toUserId;
	}

	public void setToUserId(String toUserId) {
		this.toUserId = toUserId;
	}

	public String getToPassword() {
		return toPassword;
	}

	public void setToPassword(String toPassword) {
		this.toPassword = toPassword;
	}

	public String getToOrg() {
		return toOrg;
	}

	public void setToOrg(String toOrg) {
		this.toOrg = toOrg;
	}

	/*
	public String getToEnv() {
		return toEnv;
	}*/	

	public List<String> getToEnv() {
		List<String> resourceList = Arrays.asList(this.toEnv.split(","));		
		return resourceList;
	}	

	public void setToEnv(String toEnv) {
		this.toEnv = toEnv;
	}

	/*
	 * public String getToResource() { return toResource; }
	 */

	public List<String> getToResource() {
		List<String> resourceList = Arrays.asList(this.toResource.split(","));
		return resourceList;
	}

	public void setToResource(String toResource) {
		this.toResource = toResource;
	}

	public String getExportDir() {
		return exportDir;
	}

	public void setExportDir(String exportDir) {
		this.exportDir = exportDir;
	}

	public String getImportURL() {
		return getToURL() + "/v1/organizations/" + getToOrg();
	}

	public String getImportURL(String env) {
		return getImportURL() + "/environments/" + env;
	}

	public boolean isToDeploy() {
		return toDeploy;
	}

	public void setToDeploy(boolean toDeploy) {
		this.toDeploy = toDeploy;
	}
	
	
	public String toString(){
		return "Management URL " + getToURL() + " " + 
				"User Id " + getToUserId() + " " +
				"Org " + getToOrg() + " " +
				"Env " + getToEnv() + " " +
				"Resource " + getToResource() + " " +
				"Export Dir " + getExportDir();
	}

}
