package com.prudential.apigee.config;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ExportConfig {	
	
    @Value("${from.url}")
    private String fromURL;
    
    @Value("${from.userid}")
    private String fromUserId;
    
    @Value("${from.password}")
    private String fromPassword;
    
    @Value("${from.org}")
    private String fromOrg;
    
    @Value("${from.env}")
    private String fromEnv;
        
    @Value("${from.resource}")
    private String fromResource;
        
    @Value("${export.dir}")
    private String exportDir;

	public String getExportDir() {
		return exportDir;
	}

	public void setExportDir(String exportDir) {
		this.exportDir = exportDir;
	}

	public String getFromURL() {
		return fromURL;
	}

	public void setFromURL(String fromURL) {
		this.fromURL = fromURL;
	}

	public String getFromUserId() {
		return fromUserId;
	}

	public void setFromUserId(String fromUserId) {
		this.fromUserId = fromUserId;
	}

	public String getFromPassword() {
		return fromPassword;
	}

	public void setFromPassword(String fromPassword) {
		this.fromPassword = fromPassword;
	}

	public String getFromOrg() {
		return fromOrg;
	}

	public void setFromOrg(String fromOrg) {
		this.fromOrg = fromOrg;
	}

	/*
	public String getFromEnv() {
		return fromEnv;
	}*/

	public List<String> getFromEnv() {
		List<String> envList = Arrays.asList(this.fromEnv.split(","));		
		return envList;
	}	
	
	public void setFromEnv(String fromEnv) {
		this.fromEnv = fromEnv;
	}

/*	public String getFromResource() {
		return fromResource;
	}*/
	
	public List<String> getFromResource() {
		List<String> resourceList = Arrays.asList(this.fromResource.split(","));		
		return resourceList;
	}

	public void setFromResource(String fromResource) {
		this.fromResource = fromResource;
	}
	
	public String getExportURL() {		
		return getFromURL() + "/v1/organizations/"
				+ getFromOrg();
	}
	
	public String getExportURL(String env) {		
		return getExportURL() + "/environments/" + env;
	}
	
	public String toString(){
		return "Management URL " + getFromURL() + " " + 
				"User Id " + getFromUserId() + " " +
				"Org " + getFromOrg() + " " +
				"Env " + getFromEnv() + " " +
				"Resource " + getFromResource() + " " +
				"Export Dir " + getExportDir();
	}
}
