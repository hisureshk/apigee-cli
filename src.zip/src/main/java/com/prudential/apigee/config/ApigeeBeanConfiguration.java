package com.prudential.apigee.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ApigeeBeanConfiguration {
	
	boolean isExport = true;
	
	public boolean isExport() {
		return isExport;
	}

	public void setExport(boolean isExport) {
		this.isExport = isExport;
	}
}
