package com.prudential.apigee.integration;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
public class ReferenceAPIClient extends AbstractAPIClient {
	
	/**
	 * This method invokes the Apigee Reference API to get all the references defined in an environment.
	 * @param url - Apigee Environment url form which the references will be retrieved. 
	 * @return String - The return will be a string of json which consists of defined references.
	 */
	public String getAllReferences(final String url) {
		ResponseEntity<String> response = invokeApigee(url, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee Reference API to get references details.
	 * @param url - Apigee Environment url form which the references details will be retrieved. 
	 * @param referencesName - Name of the references to get the details.
	 * @return String - The return will be a string of json which consists of defined references.
	 */
	public String getReference(final String url, final String referencesName) {
		String apiPath = url + URL_PATH + referencesName;	
		ResponseEntity<String> response = invokeApigee(apiPath, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee Reference API to create a references in the given environment with the details.
	 * @param url - Apigee Environment url in which the references will be created. 
	 * @param referencesName - Name of the references to create.
	 * @param referencesDetails - Details of the references to create.
	 * @return String - Returns the http response code of the references creation.
	 */
	public int createReference(final String url, final String referencesName, final String referencesDetails) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("name", referencesName);
		ResponseEntity<String> response = invokeApigee(builder.toUriString(), HttpMethod.POST, referencesDetails);
		return response.getStatusCodeValue();		
	}
	
	
	/**
	 * This method invokes the Apigee Reference API to update a references in the given environment with the details.
	 * @param url - Apigee Environment url in which the references will be created. 
	 * @param referencesName - Name of the references to create.
	 * @param referencesDetails - Details of the references to create.
	 * @return String - Returns the http response code of the references creation.
	 */
	public int updateReference(final String url, final String referencesName, final String referencesDetails) {
		String apiPath = url + URL_PATH + referencesName;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(apiPath);
		ResponseEntity<String> response = invokeApigee(builder.toUriString(), HttpMethod.PUT, referencesDetails);
		return response.getStatusCodeValue();		
	}
	
	/**
	 * This method invokes the Apigee Reference API to delete a references in the given environment with the details.
	 * @param url - Apigee Environment url in which the references will be created. 
	 * @param referencesName - Name of the references to create.
	 * @param referencesDetails - Details of the references to create.
	 * @return String - Returns the http response code of the references creation.
	 */
	public int deleteReference(final String url, final String referencesName) {
		String apiPath = url + URL_PATH + referencesName;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(apiPath);
		ResponseEntity<String> response = invokeApigee(builder.toUriString(), HttpMethod.DELETE);
		return response.getStatusCodeValue();		
	}


}
