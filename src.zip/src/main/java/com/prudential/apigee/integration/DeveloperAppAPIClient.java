package com.prudential.apigee.integration;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
public class DeveloperAppAPIClient extends AbstractAPIClient {
	
	/**
	 * This method invokes the Apigee DeveloperApp API to get all the developerApps defined in an organization.
	 * @param url - Apigee organization url form which the developerApps will be retrieved. 
	 * @return String - The return will be a string of json which consists of defined developerApps.
	 */
	public String getAllDeveloperApps(final String url) {
		ResponseEntity<String> response = invokeApigee(url, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee DeveloperApp API to get developerApp details.
	 * @param url - Apigee organization url form which the developerApp details will be retrieved. 
	 * @param developerAppName - Name of the developerApp to get the details.
	 * @return String - The return will be a string of json which consists of defined developerApps.
	 */
	public String getDeveloperApp(final String url, final String developerAppName) {
		String apiPath = url + URL_PATH + developerAppName;	
		ResponseEntity<String> response = invokeApigee(apiPath, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee DeveloperApp API to create a developerApp in the organization with the details.
	 * @param url - Apigee organization url in which the developerApp will be created. 
	 * @param developerAppName - Name of the developerApp to create.
	 * @param developerAppDetails - Details of the developerApp to create.
	 * @return String - Returns the http response code of the developerApp creation.
	 */
	public int createDeveloperApp(final String url, final String developerAppName, final String developerAppDetails) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("name", developerAppName);
		ResponseEntity<String> response = invokeApigee(builder.toUriString(), HttpMethod.POST, developerAppDetails);
		return response.getStatusCodeValue();		
	}
	
	/**
	 * This method invokes the Apigee DeveloperApp API to create a developerApp in the organization with the details.
	 * @param url - Apigee organization url in which the developerApp will be created. 
	 * @param developerAppName - Name of the developerApp to create.
	 * @param developerAppDetails - Details of the developerApp to create.
	 * @return String - Returns the http response code of the developerApp creation.
	 */
	public int createDeveloperAppKey(final String url, final String developerAppKeyDetails) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		ResponseEntity<String> response = invokeApigee(builder.toUriString(), HttpMethod.POST, developerAppKeyDetails);
		return response.getStatusCodeValue();		
	}

	
	/**
	 * This method invokes the Apigee DeveloperApp API to create a developerApp in the organization with the details.
	 * @param url - Apigee organization url in which the developerApp will be created. 
	 * @param developerAppName - Name of the developerApp to create.
	 * @param developerAppDetails - Details of the developerApp to create.
	 * @return String - Returns the http response code of the developerApp creation.
	 */
	public int updateDeveloperAppKey(final String url, final String developerAppKeyDetails) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		ResponseEntity<String> response = invokeApigee(builder.toUriString(), HttpMethod.POST, developerAppKeyDetails);
		return response.getStatusCodeValue();		
	}

	
	/**
	 * This method invokes the Apigee DeveloperApp API to create a developerApp in the organization with the details.
	 * @param url - Apigee organization url in which the developerApp will be created. 
	 * @param developerAppName - Name of the developerApp to create.
	 * @param developerAppDetails - Details of the developerApp to create.
	 * @return String - Returns the http response code of the developerApp creation.
	 */
	public int deleteDeveloperAppKey(final String url) {
		//UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		ResponseEntity<String> response = invokeApigee(url, HttpMethod.DELETE);
		return response.getStatusCodeValue();		
	}

}
