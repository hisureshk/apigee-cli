package com.prudential.apigee.integration;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.net.ssl.HostnameVerifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.support.BasicAuthorizationInterceptor;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.prudential.apigee.config.ApigeeBeanConfiguration;
import com.prudential.apigee.config.ExportConfig;
import com.prudential.apigee.config.ImportConfig;
import com.prudential.apigee.util.FullLoggingInterceptor;
import com.prudential.apigee.util.NullHostnameVerifier;
import com.prudential.apigee.util.SimpleHTTPClientFactory;

@Component
public class AbstractAPIClient {
	
	@Autowired
	FullLoggingInterceptor fullLoggingInterceptor;
	
	RestTemplate restTemplate;
	
	@Autowired 
	protected ExportConfig exportConfig;
	
	@Autowired 
	protected ImportConfig importConfig;
	
	@Autowired
	ApigeeBeanConfiguration beanConfig;

	static final String URL_PATH = "/";

	static final String NULL_VALUE = null;

	private static final Logger log = LoggerFactory
			.getLogger(AbstractAPIClient.class);

	ResponseEntity<String> invokeApigee(String serviceURL, HttpMethod method) {
		return invokeApigee(serviceURL, method, null);
	}

	ResponseEntity<String> invokeApigee(String serviceURL, HttpMethod method,
			String content) {
		log.debug("Invoking Apigee with params " + method + " " + serviceURL
				+ " " + content);
		restTemplate = getRestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		
		HttpEntity<String> entity = null;

		if (method.equals(HttpMethod.POST)) {
			entity = new HttpEntity<String>(content, headers);
		} else if (method.equals(HttpMethod.PUT)) {
			entity = new HttpEntity<String>(content, headers);
		} else if (method.equals(HttpMethod.GET)) {
			entity = new HttpEntity<String>(headers);
		} else {
			entity = new HttpEntity<String>(headers);
		}

		ResponseEntity<String> respEntity = null;
		try {
			respEntity = restTemplate.exchange(serviceURL, method, entity,
					String.class);
		} catch (HttpClientErrorException e) {
			if (e.getMessage().contains("401")) {
				respEntity = invokeApigee(serviceURL, method, content);
			} else {
				log.error("Error Invoking Apigee " + serviceURL + " with reason " + e.getMessage(), e.getCause());
				//throw e;
			}
		}
		return respEntity;
	}

	ResponseEntity<String> deployToApigee(String serviceURL,
			HttpMethod method) {
		restTemplate = getRestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = null;
		ResponseEntity<String> respEntity = null;

		if (method.equals(HttpMethod.POST)) {
			entity = new HttpEntity<String>(" ", headers);

			try {
				respEntity = restTemplate.postForEntity(serviceURL, entity,
						String.class);
			} catch (HttpClientErrorException e) {
				if (e.getMessage().contains("401")) {
					respEntity = deployToApigee(serviceURL, method);
				} else {
					log.error("Error Invoking Apigee " + serviceURL + " with reason " + e.getMessage(), e.getCause());
					//throw e;
				}
			}
		}
		return respEntity;
	}

	ResponseEntity<String> invokeApigee(String serviceURL, File contentFile) {
		log.debug("Invoking Apigee to create with params " + serviceURL + " "
				+ contentFile.getAbsolutePath());
		restTemplate = getRestTemplate();
		MultiValueMap<String, Object> bodyMap = new LinkedMultiValueMap<>();
		bodyMap.add("file", new FileSystemResource(contentFile));
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<MultiValueMap<String, Object>>(
				bodyMap, headers);

		ResponseEntity<String> respEntity = null;
		try {
			respEntity = restTemplate.postForEntity(serviceURL, entity,
					String.class);
		} catch (HttpClientErrorException e) {
			if (e.getMessage().contains("401")) {
				respEntity = invokeApigee(serviceURL, contentFile);
			} else {
				log.error("Error Invoking Apigee " + serviceURL + " with reason " + e.getMessage(), e.getCause());
				//throw e;
			}
		}
		return respEntity;
	}

	ResponseEntity<byte[]> invokeApigee(String serviceURL) {
		log.debug("Invoking Apigee to create with params " + serviceURL);
		restTemplate = getRestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM,
				MediaType.ALL));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ResponseEntity<byte[]> respEntity = null;
		try {
			respEntity = restTemplate.exchange(serviceURL, HttpMethod.GET,
					entity, byte[].class);
		} catch (HttpClientErrorException e) {
			if (e.getMessage().contains("401")) {
				respEntity = invokeApigee(serviceURL);
			} else {
				log.error("Error Invoking Apigee to download ", e.getCause());
				//throw e;
			}
		}
		return respEntity;
	}
			
	RestTemplate getRestTemplate() {
		List<ClientHttpRequestInterceptor> list = new ArrayList<ClientHttpRequestInterceptor>();
		list.add(fullLoggingInterceptor);
		RestTemplate restTemplate = new RestTemplateBuilder().build();
		HostnameVerifier verifier = new NullHostnameVerifier();
		SimpleHTTPClientFactory factory = new SimpleHTTPClientFactory(verifier);
		restTemplate.setRequestFactory(factory);
		//restTemplate.setInterceptors(list);
		if(beanConfig.isExport()) {
			restTemplate.getInterceptors().add(
					new BasicAuthorizationInterceptor(exportConfig.getFromUserId(),
							exportConfig.getFromPassword()));
		} else {
			restTemplate.getInterceptors().add(
					new BasicAuthorizationInterceptor(importConfig.getToUserId(),
							importConfig.getToPassword()));
		}
		return restTemplate;
	}
}
