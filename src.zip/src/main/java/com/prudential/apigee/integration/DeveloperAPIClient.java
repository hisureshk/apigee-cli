package com.prudential.apigee.integration;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
public class DeveloperAPIClient extends AbstractAPIClient {
	
	/**
	 * This method invokes the Apigee Developer API to get all the developers defined in an organization.
	 * @param url - Apigee organization url form which the developers will be retrieved. 
	 * @return String - The return will be a string of json which consists of defined developers.
	 */
	public String getAllDevelopers(final String url) {
		ResponseEntity<String> response = invokeApigee(url, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee Developer API to get developer details.
	 * @param url - Apigee organization url form which the developer details will be retrieved. 
	 * @param developerName - Name of the developer to get the details.
	 * @return String - The return will be a string of json which consists of defined developers.
	 */
	public String getDeveloper(final String url, final String developerName) {
		String apiPath = url + URL_PATH + developerName;	
		ResponseEntity<String> response = invokeApigee(apiPath, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee Developer API to create a developer in the organization with the details.
	 * @param url - Apigee organization url in which the developer will be created. 
	 * @param developerName - Name of the developer to create.
	 * @param developerDetails - Details of the developer to create.
	 * @return String - Returns the http response code of the developer creation.
	 */
	public int createDeveloper(final String url, final String developerName, final String developerDetails) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("name", developerName);
		ResponseEntity<String> response = invokeApigee(builder.toUriString(), HttpMethod.POST, developerDetails);
		return response.getStatusCodeValue();		
	}
	
	
	/**
	 * This method invokes the Apigee Developer API to update a developer in the organization with the details.
	 * @param url - Apigee organization url in which the developer will be created. 
	 * @param developerName - Name of the developer to create.
	 * @param developerDetails - Details of the developer to create.
	 * @return String - Returns the http response code of the developer creation.
	 */
	public int updateDeveloper(final String url, final String developerName, final String developerDetails) {
		String apiPath = url + URL_PATH + developerName;	
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(apiPath);
		ResponseEntity<String> response = invokeApigee(builder.toUriString(), HttpMethod.PUT, developerDetails);
		return response.getStatusCodeValue();		
	}
	
	
	/**
	 * This method invokes the Apigee Developer API to delete a developer in the organization with the details.
	 * @param url - Apigee organization url in which the developer will be created. 
	 * @param developerName - Name of the developer to create.
	 * @return String - Returns the http response code of the developer deletion.
	 */
	public int deleteDeveloper(final String url, final String developerName) {
		String apiPath = url + URL_PATH + developerName;	
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(apiPath);
		ResponseEntity<String> response = invokeApigee(builder.toUriString(), HttpMethod.DELETE);
		return response.getStatusCodeValue();		
	}

}
