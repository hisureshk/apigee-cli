package com.prudential.apigee.integration;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
public class FlowHookAPIClient extends AbstractAPIClient {
	
	/**
	 * This method invokes the Apigee FlowHook API to get all the flowhooks defined in an environment.
	 * @param url - Apigee Environment url form which the flowhooks will be retrieved. 
	 * @return String - The return will be a string of json which consists of defined flowhooks.
	 */
	public String getAllFlowHooks(final String url) {
		ResponseEntity<String> response = invokeApigee(url, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee FlowHook API to get flowhook details.
	 * @param url - Apigee Environment url form which the flowhook details will be retrieved. 
	 * @param flowhookName - Name of the flowhook to get the details.
	 * @return String - The return will be a string of json which consists of defined flowhooks.
	 */
	public String getFlowHook(final String url, final String flowhookName) {
		String apiPath = url + URL_PATH + flowhookName;	
		ResponseEntity<String> response = invokeApigee(apiPath, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee FlowHook API to create a flowhook in the given environment with the details.
	 * @param url - Apigee Environment url in which the flowhook will be created. 
	 * @param flowhookDetails - Details of the flowhook to create.
	 * @return String - Returns the http response code of the flowhook creation.
	 */
	public int createFlowHook(final String url, final String flowhookDetails) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		ResponseEntity<String> response = invokeApigee(builder.toUriString(), HttpMethod.PUT, flowhookDetails);
		return response.getStatusCodeValue();		
	}
}
