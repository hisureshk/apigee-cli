package com.prudential.apigee.integration;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
public class CacheAPIClient extends AbstractAPIClient {
	
	/**
	 * This method invokes the Apigee Cache API to get all the caches defined in an environment.
	 * @param url - Apigee Environment url form which the caches will be retrieved. 
	 * @return String - The return will be a string of json which consists of defined caches.
	 */
	public String getAllCaches(final String url) {
		ResponseEntity<String> response = invokeApigee(url, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee Cache API to get cache details.
	 * @param url - Apigee Environment url form which the cache details will be retrieved. 
	 * @param cacheName - Name of the cache to get the details.
	 * @return String - The return will be a string of json which consists of defined caches.
	 */
	public String getCache(final String url, final String cacheName) {
		String apiPath = url + URL_PATH + cacheName;	
		ResponseEntity<String> response = invokeApigee(apiPath, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee Cache API to create a cache in the given environment with the details.
	 * @param url - Apigee Environment url in which the cache will be created. 
	 * @param cacheName - Name of the cache to create.
	 * @param cacheDetails - Details of the cache to create.
	 * @return String - Returns the http response code of the cache creation.
	 */
	public int createCache(final String url, final String cacheName, final String cacheDetails) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("name", cacheName);
		ResponseEntity<String> response = invokeApigee(builder.toUriString(), HttpMethod.POST, cacheDetails);
		return response.getStatusCodeValue();		
	}

}
