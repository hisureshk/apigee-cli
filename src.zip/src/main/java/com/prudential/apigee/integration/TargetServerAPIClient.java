package com.prudential.apigee.integration;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
public class TargetServerAPIClient extends AbstractAPIClient {
	
	/**
	 * This method invokes the Apigee TargetServer API to get all the targetservers defined in an environment.
	 * @param url - Apigee Environment url form which the targetservers will be retrieved. 
	 * @return String - The return will be a string of json which consists of defined targetservers.
	 */
	public String getAllTargetServers(final String url) {
		ResponseEntity<String> response = invokeApigee(url, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee TargetServer API to get targetServer details.
	 * @param url - Apigee Environment url form which the targetServer details will be retrieved. 
	 * @param targetServerName - Name of the targetServer to get the details.
	 * @return String - The return will be a string of json which consists of defined targetservers.
	 */
	public String getTargetServer(final String url, final String targetServerName) {
		String apiPath = url + URL_PATH + targetServerName;	
		ResponseEntity<String> response = invokeApigee(apiPath, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee TargetServer API to create a targetServer in the given environment with the details.
	 * @param url - Apigee Environment url in which the targetServer will be created. 
	 * @param targetServerName - Name of the targetServer to create.
	 * @param targetServerDetails - Details of the targetServer to create.
	 * @return String - Returns the http response code of the targetServer creation.
	 */
	public int createTargetServer(final String url, final String targetServerName, final String targetServerDetails) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("name", targetServerName);
		ResponseEntity<String> response = invokeApigee(builder.toUriString(), HttpMethod.POST, targetServerDetails);
		return response.getStatusCodeValue();		
	}
	
	
	/**
	 * This method invokes the Apigee TargetServer API to update a targetServer in the given environment with the details.
	 * @param url - Apigee Environment url in which the targetServer will be created. 
	 * @param targetServerName - Name of the targetServer to create.
	 * @param targetServerDetails - Details of the targetServer to create.
	 * @return String - Returns the http response code of the targetServer creation.
	 */
	public int updateTargetServer(final String url, final String targetServerName, final String targetServerDetails) {
		String apiPath = url + URL_PATH + targetServerName;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(apiPath);
		ResponseEntity<String> response = invokeApigee(builder.toUriString(), HttpMethod.PUT, targetServerDetails);
		return response.getStatusCodeValue();		
	}
	
	/**
	 * This method invokes the Apigee TargetServer API to delete a targetServer in the given environment with the details.
	 * @param url - Apigee Environment url in which the targetServer will be created. 
	 * @param targetServerName - Name of the targetServer to create.
	 * @param targetServerDetails - Details of the targetServer to create.
	 * @return String - Returns the http response code of the targetServer creation.
	 */
	public int deleteTargetServer(final String url, final String targetServerName) {
		String apiPath = url + URL_PATH + targetServerName;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(apiPath);
		ResponseEntity<String> response = invokeApigee(builder.toUriString(), HttpMethod.DELETE);
		return response.getStatusCodeValue();		
	}


}
