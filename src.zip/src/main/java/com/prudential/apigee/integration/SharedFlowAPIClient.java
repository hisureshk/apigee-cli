package com.prudential.apigee.integration;

import java.io.File;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
public class SharedFlowAPIClient extends AbstractAPIClient {
	
	/**
	 * This method invokes the Apigee SharedFlow API to get all the sharedflows defined in an organization.
	 * @param url - Apigee organization url form which the sharedflows will be retrieved. 
	 * @return String - The return will be a string of json which consists of defined sharedflows.
	 */
	public String getAllSharedFlows(final String url) {
		ResponseEntity<String> response = invokeApigee(url, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee SharedFlow API to get sharedflow details.
	 * @param url - Apigee organization url form which the sharedflow details will be retrieved. 
	 * @param sharedflowName - Name of the sharedflow to get the details.
	 * @return String - The return will be a string of json which consists of defined sharedflows.
	 */
	public String getSharedFlow(final String url, final String sharedflowName) {
		String apiPath = url + URL_PATH + sharedflowName;	
		ResponseEntity<String> response = invokeApigee(apiPath, HttpMethod.GET);
		return response.getBody();		
	}
		
	/**
	 * This method invokes the Apigee SharedFlow API to get sharedflow details.
	 * @param url - Apigee organization url form which the sharedflow details will be retrieved. 
	 * @param sharedflowName - Name of the sharedflow to get the details.
	 * @return String - The return will be a string of json which consists of defined sharedflows.
	 */
	public String getSharedFlowDeployments(final String url, final String sharedflowName, final String revision) {
		String apiPath = url + URL_PATH + sharedflowName + "/revisions" + URL_PATH + revision + "/deployments"; 	
		ResponseEntity<String> response = invokeApigee(apiPath, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee SharedFlow API to get sharedflow details.
	 * @param url - Apigee organization url form which the sharedflow details will be retrieved. 
	 * @param sharedflowName - Name of the sharedflow to get the details.
	 * @return String - The return will be a string of json which consists of defined sharedflows.
	 */
	public byte[] getSharedFlowRevision(final String url, final String sharedflowName, final String revision) {
		String apiPath = url + URL_PATH + sharedflowName + "/revisions" + URL_PATH + revision + "?format=bundle"; 	
		ResponseEntity<byte[]> respEntity = invokeApigee(apiPath);
		return respEntity.getBody();		
	}
	
	/**
	 * This method invokes the Apigee SharedFlow API to create a sharedflow in the organization with the details.
	 * @param url - Apigee organization url in which the sharedflow will be created. 
	 * @param sharedflowName - Name of the sharedflow to create.
	 * @param sharedflowDetails - Details of the sharedflow to create.
	 * @return String - Returns the http response code of the sharedflow creation.
	 */
	public int createSharedFlow(final String url, final String sharedFlowName, final File sharedflowDetails) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("name", sharedFlowName);
		builder.queryParam("action", "import");

		ResponseEntity<String> response = invokeApigee(builder.toUriString(), sharedflowDetails);
		return response.getStatusCodeValue();		
	}
	
		
	/**
	 * This method invokes the Apigee SharedFlow API to delete a sharedflow in the organization with the details.
	 * @param url - Apigee organization url in which the sharedflow will be deleted if exists. 
	 * @param sharedflowName - Name of the sharedflow to delete.
	 * @return String - Returns the http response code of the sharedflow deletion.
	 */
	public int deleteSharedFlow(final String url, final String sharedFlowName) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		ResponseEntity<String> response = invokeApigee(builder.toUriString(), HttpMethod.DELETE);
		return response.getStatusCodeValue();		
	}

	
	/**
	 * This method invokes the Apigee SharedFlow API to deploy sharedflow.
	 * @param url - Apigee organization url form which the sharedflow will be deployed. 
	 * @param sharedflowName - Name of the sharedflow to get the details.
	 * @return String - The return will be a string of json which consists of defined sharedflows.
	 */
	public String deploySharedFlowRevision(final String url, final String sharedflowName, final String revision) {
		String apiPath = url + URL_PATH + sharedflowName + "/revisions" + URL_PATH + revision + "/deployments"; 	
		ResponseEntity<String> respEntity = deployToApigee(apiPath, HttpMethod.POST);
		return respEntity.getBody();		
	}
}
