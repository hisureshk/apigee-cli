package com.prudential.apigee.integration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.prudential.apigee.config.ExportConfig;

@Component
public class OrganizationAPIClient extends AbstractAPIClient {
	
	@Autowired
	ExportConfig exportConfig;

	
	public String getAPIPath() {
		return exportConfig.getExportURL();
	}

	/**
	 * This method invokes the Apigee Cache API to get all the caches defined in an environment.
	 * @param environment - Apigee Environment form which the caches will be retrieved. 
	 * @return String - The return will be a string of json which consists of defined caches.
	 */
	public String getAllEnvironments() {
		ResponseEntity<String> envEntity = invokeApigee(getAPIPath(), HttpMethod.GET);
		return envEntity.getBody();		
	}
	
	/**
	 * This method invokes the Apigee Cache API to get cache details.
	 * @param environment - Apigee Environment form which the caches will be retrieved. 
	 * @param cacheName - Name of the cache to get the details.
	 * @return String - The return will be a string of json which consists of defined caches.
	 */
	public String getEnvironementDetails(final String environment, final String cacheName) {
		String url = getAPIPath() + URL_PATH + environment; 
		ResponseEntity<String> cacheEntity = invokeApigee(url, HttpMethod.GET);
		return cacheEntity.getBody();		
	}

}
