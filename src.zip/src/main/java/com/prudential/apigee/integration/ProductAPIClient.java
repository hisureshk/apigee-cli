package com.prudential.apigee.integration;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
public class ProductAPIClient extends AbstractAPIClient {
	
	/**
	 * This method invokes the Apigee Product API to get all the products defined in an organization.
	 * @param url - Apigee organization url form which the products will be retrieved. 
	 * @return String - The return will be a string of json which consists of defined products.
	 */
	public String getAllProducts(final String url) {
		ResponseEntity<String> response = invokeApigee(url, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee Product API to get product details.
	 * @param url - Apigee organization url form which the product details will be retrieved. 
	 * @param productName - Name of the product to get the details.
	 * @return String - The return will be a string of json which consists of defined products.
	 */
	public String getProduct(final String url, final String productName) {
		String apiPath = url + URL_PATH + productName;	
		ResponseEntity<String> response = invokeApigee(apiPath, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee Product API to create a product in the organization with the details.
	 * @param url - Apigee organization url in which the product will be created. 
	 * @param productName - Name of the product to create.
	 * @param productDetails - Details of the product to create.
	 * @return String - Returns the http response code of the product creation.
	 */
	public int createProduct(final String url, final String productName, final String productDetails) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("name", productName);
		ResponseEntity<String> response = invokeApigee(builder.toUriString(), HttpMethod.POST, productDetails);
		return response.getStatusCodeValue();		
	}

}
