package com.prudential.apigee.integration;

import java.io.File;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
public class ProxyAPIClient extends AbstractAPIClient {
	
	/**
	 * This method invokes the Apigee APIProxy API to get all the proxies defined in an organization.
	 * @param url - Apigee organization url form which the proxies will be retrieved. 
	 * @return String - The return will be a string of json which consists of defined proxies.
	 */
	public String getAllAPIProxies(final String url) {
		ResponseEntity<String> response = invokeApigee(url, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee APIProxy API to get proxy details.
	 * @param url - Apigee organization url form which the proxy details will be retrieved. 
	 * @param proxyName - Name of the proxy to get the details.
	 * @return String - The return will be a string of json which consists of defined proxies.
	 */
	public String getAPIProxy(final String url, final String proxyName) {
		String apiPath = url + URL_PATH + proxyName;	
		ResponseEntity<String> response = invokeApigee(apiPath, HttpMethod.GET);
		return (response != null) ? response.getBody() : null;		

	}
		
	/**
	 * This method invokes the Apigee APIProxy API to get proxy details.
	 * @param url - Apigee organization url form which the proxy details will be retrieved. 
	 * @param proxyName - Name of the proxy to get the details.
	 * @return String - The return will be a string of json which consists of defined proxies.
	 */
	public String getAPIProxyDeployments(final String url, final String proxyName, final String revision) {
		String apiPath = url + URL_PATH + proxyName + "/revisions" + URL_PATH + revision + "/deployments"; 	
		ResponseEntity<String> response = invokeApigee(apiPath, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee APIProxy API to get proxy details.
	 * @param url - Apigee organization url form which the proxy details will be retrieved. 
	 * @param proxyName - Name of the proxy to get the details.
	 * @return String - The return will be a string of json which consists of defined proxies.
	 */
	public byte[] getAPIProxyRevision(final String url, final String proxyName, final String revision) {
		String apiPath = url + URL_PATH + proxyName + "/revisions" + URL_PATH + revision + "?format=bundle"; 	
		ResponseEntity<byte[]> respEntity = invokeApigee(apiPath);
		return respEntity.getBody();		
	}
	
	/**
	 * This method invokes the Apigee APIProxy API to create a proxy in the organization with the details.
	 * @param url - Apigee organization url in which the proxy will be created. 
	 * @param proxyName - Name of the proxy to create.
	 * @param proxyDetails - Details of the proxy to create.
	 * @return String - Returns the http response code of the proxy creation.
	 */
	public int createAPIProxy(final String url, final String proxyName, final File proxyDetails) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("name", proxyName);
		builder.queryParam("action", "import");

		ResponseEntity<String> response = invokeApigee(builder.toUriString(), proxyDetails);
		//return response.getStatusCodeValue();
		return (response != null) ? response.getStatusCodeValue() : -1;
	}
	
	/**
	 * This method invokes the Apigee SharedFlow API to deploy API Proxy.
	 * @param url - Apigee organization url form which the API Proxy will be deployed. 
	 * @param sharedflowName - Name of the API Proxy to get the details.
	 * @return String - The return will be a string of json which consists of status of deployed API Proxy.
	 */
	public String deployAPIProxyRevision(final String url, final String proxyName, final String revision) {
		String apiPath = url + URL_PATH + proxyName + "/revisions" + URL_PATH + revision + "/deployments"; 	
		ResponseEntity<String> respEntity = deployToApigee(apiPath, HttpMethod.POST);
		return (respEntity != null) ? respEntity.getBody() : "";		
	}

}
