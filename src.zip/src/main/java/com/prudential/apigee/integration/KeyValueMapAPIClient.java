package com.prudential.apigee.integration;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
public class KeyValueMapAPIClient extends AbstractAPIClient {
	
	/**
	 * This method invokes the Apigee KeyValueMap API to get all the keyvaluemaps defined in an environment.
	 * @param url - Apigee Environment url form which the keyvaluemaps will be retrieved. 
	 * @return String - The return will be a string of json which consists of defined keyvaluemaps.
	 */
	public String getAllKeyValueMaps(final String url) {
		ResponseEntity<String> response = invokeApigee(url, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee KeyValueMap API to get keyValueMap details.
	 * @param url - Apigee Environment url form which the keyValueMap details will be retrieved. 
	 * @param keyValueMapName - Name of the keyValueMap to get the details.
	 * @return String - The return will be a string of json which consists of defined keyvaluemaps.
	 */
	public String getKeyValueMap(final String url, final String keyValueMapName) {
		String apiPath = url + URL_PATH + keyValueMapName;	
		ResponseEntity<String> response = invokeApigee(apiPath, HttpMethod.GET);
		return response.getBody();		
	}
	
	/**
	 * This method invokes the Apigee KeyValueMap API to create a keyValueMap in the given environment with the details.
	 * @param url - Apigee Environment url in which the keyValueMap will be created. 
	 * @param keyValueMapName - Name of the keyValueMap to create.
	 * @param keyValueMapDetails - Details of the keyValueMap to create.
	 * @return String - Returns the http response code of the keyValueMap creation.
	 */
	public int createKeyValueMap(final String url, final String keyValueMapName, final String keyValueMapDetails) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("name", keyValueMapName);
		ResponseEntity<String> response = invokeApigee(builder.toUriString(), HttpMethod.POST, keyValueMapDetails);
		return response.getStatusCodeValue();		
	}

}
