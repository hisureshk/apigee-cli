package com.prudential.apigee.services;

import java.io.File;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prudential.apigee.integration.KeyValueMapAPIClient;
import com.prudential.apigee.util.FileUtil;
import com.prudential.apigee.util.ResourceTypes;

@Service
public class KeyValueMapService extends AbstractBaseService {

	private static final Logger log = LoggerFactory
			.getLogger(KeyValueMapService.class);

	@Autowired
	private KeyValueMapAPIClient keyValueMapAPIClient;

	/**
	 * This method builds the apigee keyValueMap URL to invoke based on
	 * environment and keyValueMapName being sent.
	 * 
	 * @param env
	 *            - Apigee Environment where keyValueMap will be managed.
	 * @param keyValueMapName
	 *            - Name of the keyValueMap.
	 * @return - String API path of the keyValueMap url.
	 */
	private String getKeyValueMapExportURL(String env) {
		return apigeeExportConfig.getExportURL(env) + URL_PATH
				+ ResourceTypes.KVM_RESOURCE;
	}

	/**
	 * This method builds the apigee keyValueMap URL to invoke based on
	 * environment and keyValueMapName being sent.
	 * 
	 * @param env
	 *            - Apigee Environment where keyValueMap will be managed.
	 * @param keyValueMapName
	 *            - Name of the keyValueMap.
	 * @return - String API path of the keyValueMap url.
	 */
	private String getKeyValueMapImportURL(String env) {
		return apigeeImportConfig.getImportURL(env) + URL_PATH
				+ ResourceTypes.KVM_RESOURCE;
	}

	/**
	 * This method export the defined keyValueMaps from an Apigee Organization
	 * and writes to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void exportKeyValueMaps() {
		log.info("Begin Exporting Caches .... ");
		List<String> environments = apigeeExportConfig.getFromEnv();
		if (environments.size() == 0) {
			log.error("No \"to.env\" property is set in the application.properties file "
					+ apigeeExportConfig.getFromEnv());
			return;
		}
		log.debug("Importing resources from " + apigeeExportConfig.getFromEnv());

		for (String env : environments) {
			if (env != null && !env.trim().equals("")) {
				exportKeyValueMaps(env);
			} else {
				log.warn("Blank Environment is specified in the application.properties");
			}
		}
		/*
		 * List<String> environments = getEnvironments(); for (String envn :
		 * environments) { exportKeyValueMaps(envn); }
		 */
	}

	/**
	 * This method export the keyValueMap details from an Apigee Organization
	 * and writes to a file from a given environment.
	 * 
	 * @param environment
	 *            - The Apigee environment from which keyValueMap needs to be
	 *            export.
	 */
	public void exportKeyValueMaps(final String environment) {
		log.info("Processing Export KeyValueMaps for " + environment);
		String url = getKeyValueMapExportURL(environment);
		String keyValueMapsList = keyValueMapAPIClient.getAllKeyValueMaps(url);
		List<Object> resources = jsonParser.parseList(keyValueMapsList);
		for (Object keyValueMap : resources) {
			String keyValueMapName = keyValueMap.toString().replace("\"", "")
					.trim();
			if (keyValueMapName.length() > 0 && !keyValueMapName.equals("")) {
				String keyValueMapDetails = keyValueMapAPIClient
						.getKeyValueMap(url, keyValueMapName);
				FileUtil.writeFile(apigeeExportConfig.getExportDir(),
						environment, ResourceTypes.KVM_RESOURCE,
						keyValueMapName, keyValueMapDetails, true);
			}
		}
		log.info("Completed Processing Export KeyValueMaps for " + environment);
	}

	/**
	 * This method export the defined keyValueMaps from an Apigee Organization
	 * and writes to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void importKeyValueMaps() {
		List<String> environments = apigeeImportConfig.getToEnv();
		if (environments.size() == 0) {
			log.error("No \"to.env\" property is set in the application.properties file "
					+ apigeeImportConfig.getToEnv());
			return;
		}
		log.debug("Importing resources from " + apigeeImportConfig.getToEnv());

		for (String env : environments) {
			if (env != null && !env.trim().equals("")) {
				importKeyValueMaps(env);
			} else {
				log.warn("Blank Environment is specified in the application.properties");
			}
		}
		/*
		 * List<String> environments = getEnvironments(); for (String envn :
		 * environments) { importKeyValueMaps(envn); } }
		 */
	}

	/**
	 * This method export the keyValueMap details from an Apigee Organization
	 * and writes to a file from a given environment.
	 * 
	 * @param environment
	 *            - The Apigee environment from which keyValueMap needs to be
	 *            export.
	 */
	public void importKeyValueMaps(final String environment) {
		File[] keyValueMapFiles = FileUtil.readFiles(
				apigeeImportConfig.getExportDir(), environment,
				ResourceTypes.KVM_RESOURCE, true);
		for (File cFile : keyValueMapFiles) {
			String keyValueMapName = cFile.getName();
			int pos = keyValueMapName.lastIndexOf(".");
			if (pos != -1) {
				keyValueMapName = keyValueMapName.substring(0, pos);
			}
			String keyValueMapDetails = FileUtil.readFile(cFile
					.getAbsolutePath());
			String url = getKeyValueMapImportURL(environment);
			int keyValueMapStatus = keyValueMapAPIClient.createKeyValueMap(url,
					keyValueMapName, keyValueMapDetails);
			log.info("Created KeyValueMap " + keyValueMapName
					+ " in an environment " + environment + " with status "
					+ keyValueMapStatus);
		}
		log.info("Completed Processing Import KeyValueMaps for " + environment);
	}

}
