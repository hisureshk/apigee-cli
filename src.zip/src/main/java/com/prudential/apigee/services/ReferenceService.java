package com.prudential.apigee.services;

import java.io.File;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prudential.apigee.integration.ReferenceAPIClient;
import com.prudential.apigee.util.FileUtil;
import com.prudential.apigee.util.ResourceTypes;

@Service
public class ReferenceService extends AbstractBaseService {

	private static final Logger log = LoggerFactory
			.getLogger(ReferenceService.class);

	@Autowired
	private ReferenceAPIClient referenceAPIClient;

	/**
	 * This method builds the apigee reference URL to invoke based on
	 * environment and referenceName being sent.
	 * 
	 * @param env
	 *            - Apigee Environment where reference will be managed.
	 * @param referenceName
	 *            - Name of the reference.
	 * @return - String API path of the reference url.
	 */
	private String getReferenceExportURL(String env) {
		return apigeeExportConfig.getExportURL(env) + URL_PATH
				+ ResourceTypes.REFERENCES_RESOURCE;
	}

	/**
	 * This method builds the apigee reference URL to invoke based on
	 * environment and referenceName being sent.
	 * 
	 * @param env
	 *            - Apigee Environment where reference will be managed.
	 * @param referenceName
	 *            - Name of the reference.
	 * @return - String API path of the reference url.
	 */
	private String getReferenceImportURL(String env) {
		return apigeeImportConfig.getImportURL(env) + URL_PATH
				+ ResourceTypes.REFERENCES_RESOURCE;
	}

	/**
	 * This method export the defined references from an Apigee Organization
	 * and writes to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void exportReferences() {
		List<String> environments = apigeeExportConfig.getFromEnv();
		if (environments.size() == 0) {
			log.error("No \"to.env\" property is set in the application.properties file "
					+ apigeeExportConfig.getFromEnv());
			return;
		}
		log.debug("Importing resources from " + apigeeExportConfig.getFromEnv());

		for (String env : environments) {
			if (env != null && !env.trim().equals("")) {
				exportReferences(env);
			} else {
				log.warn("Blank Environment is specified in the application.properties");
			}
		}
		/*
		 * if(types.size() == 0) { List<String> environments =
		 * getEnvironments(); for (String envn : environments) {
		 * exportReferences(envn); } }
		 */
	}

	/**
	 * This method export the reference details from an Apigee Organization
	 * and writes to a file from a given environment.
	 * 
	 * @param environment
	 *            - The Apigee environment from which reference needs to be
	 *            export.
	 */
	public void exportReferences(final String environment) {
		log.info("Processing Export References for " + environment);
		String url = getReferenceExportURL(environment);
		String referencesList = referenceAPIClient
				.getAllReferences(url);
		List<Object> resources = jsonParser.parseList(referencesList);
		for (Object reference : resources) {
			String referenceName = reference.toString().replace("\"", "")
					.trim();
			if (referenceName.length() > 0 && !referenceName.equals("")) {
				String referenceDetails = referenceAPIClient
						.getReference(url, referenceName);
				FileUtil.writeFile(apigeeExportConfig.getExportDir(),
						environment, ResourceTypes.REFERENCES_RESOURCE,
						referenceName, referenceDetails, true);
			}
		}
		log.info("Completed Processing Export References for " + environment);
	}

	/**
	 * This method export the defined references from an Apigee Organization
	 * and writes to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void importReferences() {
		List<String> environments = apigeeImportConfig.getToEnv();
		if (environments.size() == 0) {
			log.error("No \"to.env\" property is set in the application.properties file "
					+ apigeeImportConfig.getToEnv());
			return;
		}
		log.debug("Importing resources from " + apigeeImportConfig.getToEnv());

		for (String env : environments) {
			if (env != null && !env.trim().equals("")) {
				importReferences(env);
			} else {
				log.warn("Blank Environment is specified in the application.properties");
			}
		}
		/*
		 * List<String> environments = getEnvironments(); for (String envn :
		 * environments) { importReferences(envn); } }
		 */
	}

	/**
	 * This method export the reference details from an Apigee Organization
	 * and writes to a file from a given environment.
	 * 
	 * @param environment
	 *            - The Apigee environment from which reference needs to be
	 *            export.
	 */
	public void importReferences(final String environment) {
		File[] referenceFiles = FileUtil.readFiles(
				apigeeImportConfig.getExportDir(), environment,
				ResourceTypes.REFERENCES_RESOURCE, true);
		for (File cFile : referenceFiles) {
			String referenceName = cFile.getName();
			int pos = referenceName.lastIndexOf(".");
			if (pos != -1) {
				referenceName = referenceName.substring(0, pos);
			}
			String referenceDetails = FileUtil.readFile(cFile
					.getAbsolutePath());
			String url = getReferenceImportURL(environment);
			int referenceStatus = referenceAPIClient.createReference(
					url, referenceName, referenceDetails);
			log.info("CreatedReference " + referenceName
					+ " in an environment " + environment + " with status "
					+ referenceStatus);
		}
		log.info("Completed Processing ImportReferences for " + environment);
	}

}
