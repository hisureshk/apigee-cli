package com.prudential.apigee.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.BasicJsonParser;
import org.springframework.boot.json.JsonParser;
import org.springframework.stereotype.Service;

import com.prudential.apigee.config.ApigeeBeanConfiguration;
import com.prudential.apigee.config.ExportConfig;
import com.prudential.apigee.config.ImportConfig;
import com.prudential.apigee.integration.OrganizationAPIClient;

@Service
public abstract class AbstractBaseService {
	
	@Autowired protected ExportConfig apigeeExportConfig;
	
	@Autowired protected ImportConfig apigeeImportConfig;

	@Autowired protected OrganizationAPIClient organizationAPIClient;
	
	@Autowired
	ApigeeBeanConfiguration beanConfig;
	
	static final String URL_PATH =  "/";
	
	static final String NULL_VALUE =  null;
	
	protected static final JsonParser jsonParser = new BasicJsonParser();	
	
	protected List<String> getEnvironments() {
		String environmentStr = organizationAPIClient.getAllEnvironments();
		List<Object> environments = jsonParser.parseList(environmentStr);
		List<String> envStr = new ArrayList<String>(environments.size());
		for (Object env : environments) {
			String envs = env.toString().replace("\"", "").trim();
			envStr.add(envs);
		}
		return envStr;
	}	
}