package com.prudential.apigee.services;

import java.io.File;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prudential.apigee.integration.ProxyAPIClient;
import com.prudential.apigee.util.FileUtil;
import com.prudential.apigee.util.ResourceTypes;

@Service
public class APIProxyService extends AbstractBaseService {

	private static final Logger log = LoggerFactory.getLogger(ExportService.class);

	@Autowired
	private ProxyAPIClient proxyAPIClient;

	/**
	 * This method builds the apigee proxy URL to invoke based on environment and
	 * proxyName being sent.
	 * 
	 * @return - String API path of the proxy url.
	 */
	private String getAPIProxyExportURL() {
		return apigeeExportConfig.getExportURL() + URL_PATH + ResourceTypes.APIPROXY_RESOURCE;
	}

	/**
	 * This method builds the apigee proxy URL to invoke based on environment and
	 * proxyName being sent.
	 * 
	 * @return - String API path of the proxy url.
	 */
	private String getAPIProxyImportURL() {
		return apigeeImportConfig.getImportURL() + URL_PATH + ResourceTypes.APIPROXY_RESOURCE;
	}

	/**
	 * This method builds the apigee proxy URL to invoke based on environment and
	 * proxyName being sent.
	 * 
	 * @return - String API path of the proxy url.
	 */
	private String getAPIProxyDeploymentURL(String env) {
		return apigeeImportConfig.getImportURL() + "/environments/" + env + URL_PATH + ResourceTypes.APIPROXY_RESOURCE;
	}

	/**
	 * This method export the defined proxies from an Apigee Organization and writes
	 * to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	/*
	 * public void exportAPIProxies() { String url = getAPIProxyExportURL(); String
	 * proxiesList = proxyAPIClient.getAllAPIProxies(url); List<Object> resources =
	 * jsonParser.parseList(proxiesList); for (Object proxy : resources) { String
	 * proxyName = proxy.toString().replace("\"", "").trim(); String proxyDetails =
	 * proxyAPIClient.getAPIProxy(url, proxyName);
	 * FileUtil.writeFile(apigeeExportConfig.getExportDir(), NULL_VALUE,
	 * ResourceTypes.APIPROXY_RESOURCE, proxyName, proxyDetails, true);
	 * exportAPIProxyBundle(proxyName, proxyDetails); }
	 * log.info("Completed Processing Export APIProxys for "); }
	 */

	/**
	 * This method export the defined proxies from an Apigee Organization and writes
	 * to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void exportAPIProxies() {
		String url = getAPIProxyExportURL();
		String proxiesList = proxyAPIClient.getAllAPIProxies(url);
		List<Object> resources = jsonParser.parseList(proxiesList);
		resources.parallelStream().forEach(proxy -> processProxy(proxy, url));
	}

	public void processProxy(Object proxy, String url) {
		String proxyName = proxy.toString().replace("\"", "").trim();
		String proxyDetails = proxyAPIClient.getAPIProxy(url, proxyName);
		FileUtil.writeFile(apigeeExportConfig.getExportDir(), NULL_VALUE, ResourceTypes.APIPROXY_RESOURCE, proxyName,
				proxyDetails, true);
		exportAPIProxyBundle(proxyName, proxyDetails);
		log.info("Completed Processing Export APIProxys for " + proxyName);
	}

	/**
	 * This method export the defined proxies from an Apigee Organization and writes
	 * to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	@SuppressWarnings("unchecked")
	public void exportAPIProxyBundle(String proxyName, String proxyDetails) {
		String url = getAPIProxyExportURL();
		Map<String, Object> resourceMap = jsonParser.parseMap(proxyDetails);
		List<Object> revisionList = (List<Object>) resourceMap.get("revision");
		for (Object proxyRevision : revisionList) {
			String revision = proxyRevision.toString().replace("\"", "").trim();
			byte[] proxyBundle = proxyAPIClient.getAPIProxyRevision(url, proxyName, revision);
			FileUtil.writeFile(apigeeExportConfig.getExportDir(), NULL_VALUE, ResourceTypes.APIPROXY_RESOURCE,
					proxyName + "_" + revision, proxyBundle, false);
			exportAPIProxyDeployments(proxyName, revision);
		}
	}

	/**
	 * This method export the defined proxies from an Apigee Organization and writes
	 * to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void exportAPIProxyDeployments(String proxyName, String revision) {
		String url = getAPIProxyExportURL();
		String proxyDeployments = proxyAPIClient.getAPIProxyDeployments(url, proxyName, revision);
		String fileName = proxyName + "_" + revision;
		String sharedFolder = ResourceTypes.APIPROXY_RESOURCE + File.separatorChar + "deployments";
		FileUtil.writeFile(apigeeExportConfig.getExportDir(), NULL_VALUE, sharedFolder, fileName, proxyDeployments,
				true);
		log.info("Completed Processing Export APIProxys for " + proxyName + " with revision " + revision);
	}

	/**
	 * This method export the defined proxies from an Apigee Organization and writes
	 * to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void importAPIProxies() {
		String url = getAPIProxyImportURL();
		File[] proxyFiles = FileUtil.readFiles(apigeeImportConfig.getExportDir(), NULL_VALUE,
				ResourceTypes.APIPROXY_RESOURCE, false);
		for (File proxyFile : proxyFiles) {
			String proxyName = proxyFile.getName();
			int pos = proxyName.lastIndexOf("_");
			if (pos != -1) {
				proxyName = proxyName.substring(0, pos);
			}
			int proxyStatus = proxyAPIClient.createAPIProxy(url, proxyName, proxyFile);
			if (proxyStatus != -1) {
				String importedRevision = getAPIProxyRevision(url, proxyName);

				log.info("Created API Proxy " + proxyName + " with status " + proxyStatus + " and revision "
						+ importedRevision);

				deployAPIProxy(proxyFile.getName().substring(0, proxyFile.getName().indexOf(".")), importedRevision);
			}

		}
		log.info("Completed Processing Import API Proxies");

		/*
		 * boolean toDeploy = apigeeImportConfig.isToDeploy();
		 * log.info(" deployment is " + toDeploy); if (toDeploy) { deployAPIProxies(); }
		 */
	}

	/**
	 * This method returns the last deployed revision of a API proxy.
	 * 
	 * @see application.properties file to configure.
	 */
	@SuppressWarnings("unchecked")
	public String getAPIProxyRevision(String url, String proxyName) {

		String proxyDetails = proxyAPIClient.getAPIProxy(url, proxyName);

		String lastRevision = null;
		Map<String, Object> resourceMap = jsonParser.parseMap(proxyDetails);
		List<Object> revisionList = (List<Object>) resourceMap.get("revision");
		for (Object proxyRevision : revisionList) {
			lastRevision = proxyRevision.toString().replace("\"", "").trim();
		}
		return lastRevision;

	}

	/**
	 * This method deploy the defined sharedFlows into an Apigee Organization
	 * 
	 * @see application.properties file to configure.
	 */
	@SuppressWarnings("unchecked")
	public void deployAPIProxy(String apiProxyFileName, String importedRevision) {

		String apiProxyFilePath = apigeeImportConfig.getExportDir() + File.separatorChar
				+ ResourceTypes.APIPROXY_RESOURCE + File.separatorChar + "deployments" + File.separatorChar
				+ apiProxyFileName + ".json";
		String apiProxyName = apiProxyFileName;

		int pos = apiProxyName.lastIndexOf("_");
		if (pos != -1) {
			apiProxyName = apiProxyName.substring(0, pos);
		}
		String apiProxyDetails = FileUtil.readFile(apiProxyFilePath);

		Map<String, Object> resourceMap = jsonParser.parseMap(apiProxyDetails);

		List<Object> envList = (List<Object>) resourceMap.get("environment");

		String revision = (String) resourceMap.get("name");
		if (!revision.equals(importedRevision)) {
			revision = importedRevision;
		}

		for (Object env : envList) {
			String envDetails = env.toString().replace("\"", "").trim();

			if (!envDetails.isEmpty()) {
				Map<String, Object> envMap = jsonParser.parseMap(envDetails);
				String envName = (String) envMap.get("name");
				String url = getAPIProxyDeploymentURL(envName);
				String apiProxyStatus = proxyAPIClient.deployAPIProxyRevision(url, apiProxyName, revision);
				log.info("Created Proxy " + apiProxyName + " with status " + apiProxyStatus);
			}
		}
		log.info("Deployment Completed for API Proxy " + apiProxyFileName + " with revision " + importedRevision);
	}

	/**
	 * This method deploy the defined apiProxys into an Apigee Organization
	 * 
	 * @see application.properties file to configure.
	 */
	@SuppressWarnings("unchecked")
	public void deployAPIProxies() {

		String sharedFolder = ResourceTypes.APIPROXY_RESOURCE + File.separatorChar + "deployments";
		File[] apiProxiesFiles = FileUtil.readFiles(apigeeImportConfig.getExportDir(), NULL_VALUE, sharedFolder, true);
		for (File apiProxyFile : apiProxiesFiles) {
			String apiProxyName = apiProxyFile.getName();
			int pos = apiProxyName.lastIndexOf("_");
			if (pos != -1) {
				apiProxyName = apiProxyName.substring(0, pos);
			}
			String apiProxyDetails = FileUtil.readFile(apiProxyFile.getAbsolutePath());
			Map<String, Object> resourceMap = jsonParser.parseMap(apiProxyDetails);
			List<Object> envList = (List<Object>) resourceMap.get("environment");

			String revision = (String) resourceMap.get("name");

			for (Object env : envList) {
				String envDetails = env.toString().replace("\"", "").trim();

				if (!envDetails.isEmpty()) {
					Map<String, Object> envMap = jsonParser.parseMap(envDetails);
					String envName = (String) envMap.get("name");
					String url = getAPIProxyDeploymentURL(envName);
					String apiProxyStatus = proxyAPIClient.deployAPIProxyRevision(url, apiProxyName, revision);
					log.info("Created Proxy " + apiProxyName + " with status " + apiProxyStatus);
				}
			}
			log.info("Completed Processing Deployment Proxies ");
		}
	}
}
