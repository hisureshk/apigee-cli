package com.prudential.apigee.services;

import java.io.File;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prudential.apigee.integration.CacheAPIClient;
import com.prudential.apigee.util.FileUtil;
import com.prudential.apigee.util.ResourceTypes;

@Service
public class CacheService extends AbstractBaseService {

	private static final Logger log = LoggerFactory
			.getLogger(CacheService.class);

	@Autowired
	private CacheAPIClient cacheAPIClient;

	/**
	 * This method builds the apigee cache URL to invoke based on environment
	 * and cacheName being sent.
	 * 
	 * @param env
	 *            - Apigee Environment where cache will be managed.
	 * @param cacheName
	 *            - Name of the cache.
	 * @return - String API path of the cache url.
	 */
	private String getCacheExportURL(String env) {
		return apigeeExportConfig.getExportURL(env) + URL_PATH
				+ ResourceTypes.CACHE_RESOURCE;
	}

	/**
	 * This method builds the apigee cache URL to invoke based on environment
	 * and cacheName being sent.
	 * 
	 * @param env
	 *            - Apigee Environment where cache will be managed.
	 * @param cacheName
	 *            - Name of the cache.
	 * @return - String API path of the cache url.
	 */
	private String getCacheImportURL(String env) {
		return apigeeImportConfig.getImportURL(env) + URL_PATH
				+ ResourceTypes.CACHE_RESOURCE;
	}

	/**
	 * This method export the defined caches from an Apigee Organization and
	 * writes to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void exportCaches() {
		log.info("Begin Exporting Caches .... ");
		List<String> environments = apigeeExportConfig.getFromEnv();
		if (environments.size() == 0) {
			log.error("No \"to.env\" property is set in the application.properties file "
					+ apigeeExportConfig.getFromEnv());
			return;
		}
		log.debug("Exporting resources from " + apigeeExportConfig.getFromEnv());

		for (String env : environments) {
			if (env != null && !env.trim().equals("")) {
				exportCaches(env);
			} else {
				log.warn("Blank Environment is specified in the application.properties");
			}
		}
		/*
		 * List<String> environments = getEnvironments(); for (String envn :
		 * environments) { exportCaches(envn); } }
		 */
		log.info("End Exporting Caches .... ");
	}

	/**
	 * This method export the cache details from an Apigee Organization and
	 * writes to a file from a given environment.
	 * 
	 * @param environment
	 *            - The Apigee environment from which cache needs to be export.
	 */
	public void exportCaches(final String environment) {
		log.info("Begin Export Caches for " + environment);
		String url = getCacheExportURL(environment);
		String cachesList = cacheAPIClient.getAllCaches(url);
		List<Object> resources = jsonParser.parseList(cachesList);
		for (Object cache : resources) {
			String cacheName = cache.toString().replace("\"", "").trim();
			if (cacheName.length() > 0 && !cacheName.equals("")) {
				String cacheDetails = cacheAPIClient.getCache(url, cacheName);
				FileUtil.writeFile(apigeeExportConfig.getExportDir(),
						environment, ResourceTypes.CACHE_RESOURCE, cacheName,
						cacheDetails, true);
			}
		}
		log.info("End Processing Export Caches for " + environment);
	}

	/**
	 * This method export the defined caches from an Apigee Organization and
	 * writes to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void importCaches() {
		log.info("Begin Importing Caches .... ");
		List<String> environments = apigeeImportConfig.getToEnv();
		if (environments.size() == 0) {
			log.error("No \"to.env\" property is set in the application.properties file "
					+ apigeeImportConfig.getToEnv());
			return;
		}
		log.debug("Importing resources from " + apigeeImportConfig.getToEnv());

		for (String env : environments) {
			if (env != null && !env.trim().equals("")) {
				importCaches(env);
			} else {
				log.warn("Blank Environment is specified in the application.properties");
			}
		}
		/*
		 * List<String> environments = getEnvironments(); for (String envn :
		 * environments) { importCaches(envn); } }
		 */
		log.debug("End Importing Caches .... ");
	}

	/**
	 * This method export the cache details from an Apigee Organization and
	 * writes to a file from a given environment.
	 * 
	 * @param environment
	 *            - The Apigee environment from which cache needs to be export.
	 */
	public void importCaches(final String environment) {
		log.info("Begin Import Caches for " + environment);
		File[] cacheFiles = FileUtil.readFiles(
				apigeeImportConfig.getExportDir(), environment,
				ResourceTypes.CACHE_RESOURCE, true);
		String url = getCacheImportURL(environment);
		for (File cFile : cacheFiles) {
			String cacheName = cFile.getName();
			int pos = cacheName.lastIndexOf(".");
			if (pos != -1) {
				cacheName = cacheName.substring(0, pos);
			}
			String cacheDetails = FileUtil.readFile(cFile.getAbsolutePath());
			int cacheStatus = cacheAPIClient.createCache(url, cacheName,
					cacheDetails);
			log.debug("Created Cache " + cacheName + " in an environment "
					+ environment + " with status " + cacheStatus);
		}
		log.info("End Import Caches for " + environment);

	}

}
