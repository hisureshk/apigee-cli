package com.prudential.apigee.services;

import java.io.File;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prudential.apigee.integration.ProductAPIClient;
import com.prudential.apigee.util.FileUtil;
import com.prudential.apigee.util.ResourceTypes;

@Service
public class ProductService extends AbstractBaseService {

	private static final Logger log = LoggerFactory
			.getLogger(ProductService.class);
	
	@Autowired
	private ProductAPIClient productAPIClient;
	
	
	/**
	 * This method builds the apigee product URL to invoke based on environment and productName being sent.
	 * @return - String API path of the product url.
	 */
	private String getProductExportURL() {
		return apigeeExportConfig.getExportURL() + URL_PATH + ResourceTypes.APIPRODUCTS_RESOURCE;
	}
	
	
	/**
	 * This method builds the apigee product URL to invoke based on environment and productName being sent.
	 * @return - String API path of the product url.
	 */
	private String getProductImportURL() {
		return apigeeImportConfig.getImportURL() + URL_PATH + ResourceTypes.APIPRODUCTS_RESOURCE;
	}
	
	
	
	/**
	 * This method export the defined products from an Apigee Organization and writes to a folder as defined in the property file.
	 * @see application.properties file to configure.
	 */
	public void exportProducts() {
		String url = getProductExportURL();		
		String productsList = productAPIClient.getAllProducts(url);
		List<Object> resources = jsonParser.parseList(productsList);
		for (Object product : resources) {
			String productName = product.toString().replace("\"", "").trim();
			String productDetails = productAPIClient.getProduct(url, productName);
			FileUtil.writeFile(apigeeExportConfig.getExportDir(), NULL_VALUE, ResourceTypes.APIPRODUCTS_RESOURCE, productName, productDetails, true);			
		}
		log.info("Completed Processing Export Products for ");
	}
	
	
	/**
	 * This method import the defined products from an exported a folder as defined in the property file into an Apigee Organization.
	 * @see application.properties file to configure.
	 */
	public void importProducts() {
		File[] productFiles = FileUtil.readFiles(apigeeImportConfig.getExportDir(), NULL_VALUE, ResourceTypes.APIPRODUCTS_RESOURCE, true);
		for (File cFile : productFiles) {
			String productName = cFile.getName();
			int pos = productName.lastIndexOf(".");
			if (pos != -1) {
				productName = productName.substring(0, pos);
			}			
			String productDetails = FileUtil.readFile(cFile.getAbsolutePath());
			String url = getProductImportURL();
			int productStatus = productAPIClient.createProduct(url, productName, productDetails);
			log.info("Created Product " + productName + " with status " + productStatus);
		}
		log.info("Completed Processing Import Products ");
	}

}
