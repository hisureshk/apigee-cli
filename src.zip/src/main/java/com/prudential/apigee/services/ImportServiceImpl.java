package com.prudential.apigee.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prudential.apigee.util.ResourceTypes;

@Service
public class ImportServiceImpl extends AbstractBaseService implements ImportService {

	@Autowired
	CacheService cacheService;

	@Autowired
	TargetServerService targetServerService;

	@Autowired
	ReferenceService referenceService;

	@Autowired
	SharedFlowService sharedFlowService;

	@Autowired
	FlowHookService flowHookService;

	@Autowired
	APIProxyService apiProxyService;

	@Autowired
	ProductService productService;

	@Autowired
	KeyValueMapService keyValueMapService;

	@Autowired
	DeveloperService developerService;

	private static final Logger log = LoggerFactory
			.getLogger(ImportService.class);

	
	public void importResources() {
		beanConfig.setExport(false);
		List<String> types = apigeeImportConfig.getToResource();
		if (types.size() == 0) {
			log.error("No \"to.resource\" property is set in the application.properties file "
					+ apigeeImportConfig.getToResource());
			return;
		}
		log.debug("Importing resources using " + apigeeImportConfig.toString());

		for (String type : types) {
			processResource(type);
		}
	}
	
	
/*	public void importResources() {
		beanConfig.setExport(false);
		List<String> types = apigeeImportConfig.getToResource();
		if (types.size() == 0) {
			log.error("No \"to.resource\" property is set in the application.properties file "
					+ apigeeImportConfig.getToResource());
			return;
		}
		log.debug("Importing resources using " + apigeeImportConfig.toString());	
		types.parallelStream().forEach(type -> processResource(type));			
	}*/

	public void processResource(String type) {
		switch (type) {
		case ResourceTypes.CACHE_RESOURCE:
			cacheService.importCaches();
			break;
		case ResourceTypes.KVM_RESOURCE:
			keyValueMapService.importKeyValueMaps();
			break;
		case ResourceTypes.TARGETSERVERS_RESOURCE:
			targetServerService.importTargetServers();
			break;
		case ResourceTypes.REFERENCES_RESOURCE:
			referenceService.importReferences();
			break;
		case ResourceTypes.FLOWHOOKS_RESOURCE:
			flowHookService.importFlowHooks();
			break;
		case ResourceTypes.SHAREDFLOWS_RESOURCE:
			sharedFlowService.importSharedFlows();
			break;
		case ResourceTypes.APIPROXY_RESOURCE:
			apiProxyService.importAPIProxies();
			break;
		case ResourceTypes.APIPRODUCTS_RESOURCE:
			productService.importProducts();
			break;
		case ResourceTypes.DEVELOPERS_RESOURCE:
			developerService.importDevelopers();
			break;
		default:
			log.error("Unsupported Resource specified in the application.properites file "
					+ apigeeImportConfig.getToResource());
			break;
		}
	}

	public void ImportApigeeResources() {
		log.info("config able to read is " + apigeeImportConfig.getToURL());
	}


	@Override
	public void importResources(String environment) {
		// TODO Auto-generated method stub
		
	}
}
