package com.prudential.apigee.services;

import java.io.File;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prudential.apigee.integration.TargetServerAPIClient;
import com.prudential.apigee.util.FileUtil;
import com.prudential.apigee.util.ResourceTypes;

@Service
public class TargetServerService extends AbstractBaseService {

	private static final Logger log = LoggerFactory
			.getLogger(TargetServerService.class);

	@Autowired
	private TargetServerAPIClient targetServerAPIClient;

	/**
	 * This method builds the apigee targetServer URL to invoke based on
	 * environment and targetServerName being sent.
	 * 
	 * @param env
	 *            - Apigee Environment where targetServer will be managed.
	 * @param targetServerName
	 *            - Name of the targetServer.
	 * @return - String API path of the targetServer url.
	 */
	private String getTargetServerExportURL(String env) {
		return apigeeExportConfig.getExportURL(env) + URL_PATH
				+ ResourceTypes.TARGETSERVERS_RESOURCE;
	}

	/**
	 * This method builds the apigee targetServer URL to invoke based on
	 * environment and targetServerName being sent.
	 * 
	 * @param env
	 *            - Apigee Environment where targetServer will be managed.
	 * @param targetServerName
	 *            - Name of the targetServer.
	 * @return - String API path of the targetServer url.
	 */
	private String getTargetServerImportURL(String env) {
		return apigeeImportConfig.getImportURL(env) + URL_PATH
				+ ResourceTypes.TARGETSERVERS_RESOURCE;
	}

	/**
	 * This method export the defined targetServers from an Apigee Organization
	 * and writes to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void exportTargetServers() {
		List<String> environments = apigeeExportConfig.getFromEnv();
		if (environments.size() == 0) {
			log.error("No \"to.env\" property is set in the application.properties file "
					+ apigeeExportConfig.getFromEnv());
			return;
		}
		log.debug("Importing resources from " + apigeeExportConfig.getFromEnv());

		for (String env : environments) {
			if (env != null && !env.trim().equals("")) {
				exportTargetServers(env);
			} else {
				log.warn("Blank Environment is specified in the application.properties");
			}
		}
		/*
		 * if(types.size() == 0) { List<String> environments =
		 * getEnvironments(); for (String envn : environments) {
		 * exportTargetServers(envn); } }
		 */
	}

	/**
	 * This method export the targetServer details from an Apigee Organization
	 * and writes to a file from a given environment.
	 * 
	 * @param environment
	 *            - The Apigee environment from which targetServer needs to be
	 *            export.
	 */
	public void exportTargetServers(final String environment) {
		log.info("Processing Export TargetServers for " + environment);
		String url = getTargetServerExportURL(environment);
		String targetServersList = targetServerAPIClient
				.getAllTargetServers(url);
		List<Object> resources = jsonParser.parseList(targetServersList);
		for (Object targetServer : resources) {
			String targetServerName = targetServer.toString().replace("\"", "")
					.trim();
			if (targetServerName.length() > 0 && !targetServerName.equals("")) {
				String targetServerDetails = targetServerAPIClient
						.getTargetServer(url, targetServerName);
				FileUtil.writeFile(apigeeExportConfig.getExportDir(),
						environment, ResourceTypes.TARGETSERVERS_RESOURCE,
						targetServerName, targetServerDetails, true);
			}
		}
		log.info("Completed Processing Export TargetServers for " + environment);
	}

	/**
	 * This method export the defined targetServers from an Apigee Organization
	 * and writes to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void importTargetServers() {
		List<String> environments = apigeeImportConfig.getToEnv();
		if (environments.size() == 0) {
			log.error("No \"to.env\" property is set in the application.properties file "
					+ apigeeImportConfig.getToEnv());
			return;
		}
		log.debug("Importing resources from " + apigeeImportConfig.getToEnv());

		for (String env : environments) {
			if (env != null && !env.trim().equals("")) {
				importTargetServers(env);
			} else {
				log.warn("Blank Environment is specified in the application.properties");
			}
		}
		/*
		 * List<String> environments = getEnvironments(); for (String envn :
		 * environments) { importTargetServers(envn); } }
		 */
	}

	/**
	 * This method export the targetServer details from an Apigee Organization
	 * and writes to a file from a given environment.
	 * 
	 * @param environment
	 *            - The Apigee environment from which targetServer needs to be
	 *            export.
	 */
	public void importTargetServers(final String environment) {
		File[] targetServerFiles = FileUtil.readFiles(
				apigeeImportConfig.getExportDir(), environment,
				ResourceTypes.TARGETSERVERS_RESOURCE, true);
		for (File cFile : targetServerFiles) {
			String targetServerName = cFile.getName();
			int pos = targetServerName.lastIndexOf(".");
			if (pos != -1) {
				targetServerName = targetServerName.substring(0, pos);
			}
			String targetServerDetails = FileUtil.readFile(cFile
					.getAbsolutePath());
			String url = getTargetServerImportURL(environment);
			int targetServerStatus = targetServerAPIClient.createTargetServer(
					url, targetServerName, targetServerDetails);
			log.info("CreatedTargetServer " + targetServerName
					+ " in an environment " + environment + " with status "
					+ targetServerStatus);
		}
		log.info("Completed Processing ImportTargetServers for " + environment);
	}

}
