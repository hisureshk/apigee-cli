package com.prudential.apigee.services;

import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prudential.apigee.integration.DeveloperAPIClient;
import com.prudential.apigee.integration.DeveloperAppAPIClient;
import com.prudential.apigee.util.FileUtil;
import com.prudential.apigee.util.ResourceTypes;

@Service
public class DeveloperService extends AbstractBaseService {

	private static final Logger log = LoggerFactory
			.getLogger(DeveloperService.class);

	@Autowired
	private DeveloperAPIClient developerAPIClient;

	@Autowired
	private DeveloperAppAPIClient developerAppAPIClient;

	/**
	 * This method builds the apigee developer URL to invoke based on
	 * environment and developerName being sent.
	 * 
	 * @return - String API path of the developer url.
	 */
	private String getDeveloperExportURL() {
		return apigeeExportConfig.getExportURL() + URL_PATH
				+ ResourceTypes.DEVELOPERS_RESOURCE;
	}

	/**
	 * This method builds the apigee developer URL to invoke based on
	 * environment and developerName being sent. *
	 * 
	 * @return - String API path of the developer url.
	 */
	private String getDeveloperImportURL() {
		return apigeeImportConfig.getImportURL() + URL_PATH
				+ ResourceTypes.DEVELOPERS_RESOURCE;
	}

	/**
	 * This method builds the apigee developer URL to invoke based on
	 * environment and developerName being sent.
	 * 
	 * @param developerID
	 *            - ID of the developer to export the apps.
	 * @return - String API path of the developer url.
	 */
	private String getDeveloperAppExportURL(String developerID) {
		return getDeveloperExportURL() + URL_PATH + developerID + URL_PATH
				+ ResourceTypes.DEVELOPERAPPS_RESOURCE;
	}

	/**
	 * This method builds the apigee developer URL to invoke based on
	 * environment and developerName being sent.
	 * 
	 * @param developerID
	 *            - ID of the developer to import the apps.
	 * @return - String API path of the developer url.
	 */
	private String getDeveloperAppImportURL(String developerID) {
		return getDeveloperImportURL() + URL_PATH + developerID + URL_PATH
				+ ResourceTypes.DEVELOPERAPPS_RESOURCE;
	}

	/**
	 * This method builds the apigee developer URL to invoke based on
	 * environment and developerName being sent.
	 * 
	 * @param developerID
	 *            - ID of the developer to import the apps.
	 * @return - String API path of the developer url.
	 */
	private String getDeveloperAppKeyImportURL(String developerID, String appID) {
		return getDeveloperImportURL() + URL_PATH + developerID + URL_PATH
				+ ResourceTypes.DEVELOPERAPPS_RESOURCE + URL_PATH + appID
				+ "/keys/create";
	}
	
	
	/**
	 * This method builds the apigee developer URL to invoke based on
	 * environment and developerName being sent.
	 * 
	 * @param developerID
	 *            - ID of the developer to import the apps.
	 * @return - String API path of the developer url.
	 */
	private String getDeveloperAppKeyURL(String developerID, String appID, String keyID) {
		return getDeveloperImportURL() + URL_PATH + developerID + URL_PATH
				+ ResourceTypes.DEVELOPERAPPS_RESOURCE + URL_PATH + appID
				+ URL_PATH + ResourceTypes.DEVELOPERAPPKEYS_RESOURCE+ URL_PATH + keyID;
	}

	/**
	 * This method export the defined developers from an Apigee Organization and
	 * writes to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void exportDevelopers() {
		String url = getDeveloperExportURL();
		String developersList = developerAPIClient.getAllDevelopers(url);
		List<Object> resources = jsonParser.parseList(developersList);
		for (Object developer : resources) {
			String developerName = developer.toString().replace("\"", "")
					.trim();
			String developerDetails = developerAPIClient.getDeveloper(url,
					developerName);
			FileUtil.writeFile(apigeeExportConfig.getExportDir(), NULL_VALUE,
					ResourceTypes.DEVELOPERS_RESOURCE, developerName,
					developerDetails, true);
			exportDeveloperApps(developerName);
		}
		log.info("Completed Processing Export Developers for ");
	}

	/**
	 * This method export the defined developer apps from an Apigee Organization
	 * and writes to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	@SuppressWarnings("unchecked")
	public void exportDeveloperApps(String apiDeveloperName) {
		String url = getDeveloperAppExportURL(apiDeveloperName);
		String developerAppsList = developerAppAPIClient
				.getAllDeveloperApps(url);
		List<Object> resources = jsonParser.parseList(developerAppsList);
		for (Object developerApp : resources) {
			String developerAppName = developerApp.toString().replace("\"", "")
					.trim();
			if (!developerAppName.trim().equals("")) {
				String developerAppDetails = developerAppAPIClient
						.getDeveloperApp(url, developerAppName);
				String folderName = ResourceTypes.DEVELOPERS_RESOURCE
						+ File.separatorChar + apiDeveloperName
						+ File.separatorChar
						+ ResourceTypes.DEVELOPERAPPS_RESOURCE;
				FileUtil.writeFile(apigeeExportConfig.getExportDir(),
						NULL_VALUE, folderName, developerAppName,
						developerAppDetails, true);

				Map<String, Object> resourceMap = jsonParser
						.parseMap(developerAppDetails);
				List<String> consumerKeyInfo = (List<String>) resourceMap
						.get("credentials");
				for (String consumerKey : consumerKeyInfo) {
					if (!consumerKey.trim().equals("")) {
						exportDeveloperAppKeys(apiDeveloperName,
								developerAppName, consumerKey);
					}
				}
			}
		}
		log.info("Completed Processing Export Developers for ");
	}

	/**
	 * This method export the defined developer app keys from an Apigee
	 * Organization and writes to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void exportDeveloperAppKeys(String apiDeveloperName,
			String devAppName, String consumerKeyInfo) {
		Map<String, Object> resourceMap = jsonParser.parseMap(consumerKeyInfo);
		String consumerKeyID = ((String) resourceMap.get("consumerKey"))
				.replace("\"", "").trim();
		String folderName = ResourceTypes.DEVELOPERS_RESOURCE
				+ File.separatorChar + apiDeveloperName + File.separatorChar
				+ ResourceTypes.DEVELOPERAPPS_RESOURCE + File.separatorChar
				+ devAppName + File.separatorChar
				+ ResourceTypes.DEVELOPERAPPKEYS_RESOURCE;
		FileUtil.writeFile(apigeeExportConfig.getExportDir(), null, folderName,
				consumerKeyID, consumerKeyInfo, true);
	}

	/**
	 * This method import the defined developers from an Apigee Organization and
	 * writes to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void importDevelopers() {
		File[] developerFiles = FileUtil.readFiles(
				apigeeImportConfig.getExportDir(), NULL_VALUE,
				ResourceTypes.DEVELOPERS_RESOURCE, true);
		for (File cFile : developerFiles) {
			String developerName = cFile.getName();
			int pos = developerName.lastIndexOf(".");
			if (pos != -1) {
				developerName = developerName.substring(0, pos);
			}
			// Ignore the SVC_APIGEE prod and npn-prod user
			if (!developerName
					.equalsIgnoreCase("SVC_APIGEE_NONPROD@production.local")
					&& !developerName
							.equalsIgnoreCase("SVC_APIGEE_PROD@production.local")) {
				String developerDetails = FileUtil.readFile(cFile
						.getAbsolutePath());
				String url = getDeveloperImportURL();
				int developerStatus = developerAPIClient.createDeveloper(url,
						developerName, developerDetails);
				log.info("Created Developer" + developerName + " with status "
						+ developerStatus);
			}
			importDeveloperApps(developerName); // TODO
		}
		importDeveloperAppKeys();
		log.info("Completed Processing Import Developers ");
	}

	/**
	 * This method imports the defined developers from an Apigee Organization
	 * and writes to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void importDeveloperApps(String apiDeveloperName) {
		String folderName = ResourceTypes.DEVELOPERS_RESOURCE
				+ File.separatorChar + apiDeveloperName + File.separatorChar
				+ ResourceTypes.DEVELOPERAPPS_RESOURCE;
		/*
		 * String folderName = ResourceTypes.DEVELOPERS_RESOURCE +
		 * File.separatorChar + ResourceTypes.DEVELOPERAPPS_RESOURCE;
		 */
		File[] developerAppsFiles = FileUtil
				.readFiles(apigeeImportConfig.getExportDir(), NULL_VALUE,
						folderName, true);
		if (developerAppsFiles != null) {
			for (File devAppFile : developerAppsFiles) {
				String developerAppName = devAppFile.getName();
				int pos = developerAppName.lastIndexOf(".");
				if (pos != -1) {
					developerAppName = developerAppName.substring(0, pos);
				}
				String developerAppDetails = FileUtil.readFile(devAppFile
						.getAbsolutePath());
				String url = getDeveloperAppImportURL(apiDeveloperName);
				int developerAppStatus = developerAppAPIClient
						.createDeveloperApp(url, developerAppName,
								developerAppDetails);
				log.debug("Created Developer App " + developerAppName
						+ " with status " + developerAppStatus);
			}
		}
		log.info("Completed Processing Import Developers Apps ");
	}
	
	public void importDeveloperAppKeys() {
		deleteDeveloperAppKeys();
		try {
			createDeveloperAppKeys();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This method import the developer appKeys into an Apigee Organization 
	 * from a property file.
	 * 
	 * @see application.properties file to configure.
	 */
	
	public void deleteDeveloperAppKeys() {
		File[] developerFiles = FileUtil.readFiles(
				apigeeImportConfig.getExportDir(), NULL_VALUE,
				ResourceTypes.DEVELOPERS_RESOURCE, true);
		for (File cFile : developerFiles) {
			String developerName = cFile.getName();
			int pos = developerName.lastIndexOf(".");
			if (pos != -1) {
				developerName = developerName.substring(0, pos);
			}
			deleteDeveloperAppKeys(developerName);			
		}		
		log.info("Completed Processing Import Developers ");
	}
	
	@SuppressWarnings("unchecked")
	public void deleteDeveloperAppKeys(String apiDeveloperName) {

		String appFolderName = ResourceTypes.DEVELOPERS_RESOURCE
				+ File.separatorChar + apiDeveloperName + File.separatorChar
				+ ResourceTypes.DEVELOPERAPPS_RESOURCE;
		File[] developerAppsFiles = FileUtil.readFiles(
				apigeeImportConfig.getExportDir(), NULL_VALUE, appFolderName,
				true);
		if (developerAppsFiles != null) {
			for (File devAppFile : developerAppsFiles) {
				String developerAppName = devAppFile.getName();
				int pos = developerAppName.lastIndexOf(".");
				if (pos != -1) {
					developerAppName = developerAppName.substring(0, pos);
				}				
				String url = getDeveloperAppImportURL(apiDeveloperName);				
				String developerAppDetails = developerAppAPIClient
						.getDeveloperApp(url, developerAppName);
				Map<String, Object> resourceMap = jsonParser
						.parseMap(developerAppDetails);
				List<String> consumerKeyInfo = (List<String>) resourceMap.get("credentials");
				for (String consumerKey : consumerKeyInfo) {
					if (!consumerKey.trim().equals("")) {
						deleteDeveloperAppKeys(apiDeveloperName,
								developerAppName, consumerKey);
					}
				}				
			}
		}
		log.info("Completed Processing Import Developers App Keys ");
	}
	
	
	public void deleteDeveloperAppKeys(String apiDeveloperName, String developerAppName, String consumerKeyInfo){
		Map<String, Object> resourceMap = jsonParser.parseMap(consumerKeyInfo);
		String consumerKeyID = ((String) resourceMap.get("consumerKey"))
				.replace("\"", "").trim();
		String url = getDeveloperAppKeyURL(
				apiDeveloperName, developerAppName, consumerKeyID);
		int developerAppKeyStatus = developerAppAPIClient
				.deleteDeveloperAppKey(url);
		log.debug("Deleted Developer AppKey "
				+ consumerKeyID + " with status "
				+ developerAppKeyStatus);
	}
	
	
	public void createDeveloperAppKeys() throws ParseException {
		File[] developerFiles = FileUtil.readFiles(
				apigeeImportConfig.getExportDir(), NULL_VALUE,
				ResourceTypes.DEVELOPERS_RESOURCE, true);
		for (File cFile : developerFiles) {
			String developerName = cFile.getName();
			int pos = developerName.lastIndexOf(".");
			if (pos != -1) {
				developerName = developerName.substring(0, pos);
			}
			createDeveloperAppKeys(developerName);			
		}		
		log.info("Completed Processing Import Developers ");
	}

	/**
	 * This method imports the defined developer app keys from an Apigee
	 * Organization and writes to a folder as defined in the property file.
	 * @throws ParseException 
	 * 
	 * @see application.properties file to configure.
	 */
	public void createDeveloperAppKeys(String apiDeveloperName) throws ParseException{

		String appFolderName = ResourceTypes.DEVELOPERS_RESOURCE
				+ File.separatorChar + apiDeveloperName + File.separatorChar
				+ ResourceTypes.DEVELOPERAPPS_RESOURCE;
		File[] developerAppsFiles = FileUtil.readFiles(
				apigeeImportConfig.getExportDir(), NULL_VALUE, appFolderName,
				true);
		if (developerAppsFiles != null) {
			for (File devAppFile : developerAppsFiles) {
				String developerAppName = devAppFile.getName();
				int pos = developerAppName.lastIndexOf(".");
				if (pos != -1) {
					developerAppName = developerAppName.substring(0, pos);
				}
				String folderName = ResourceTypes.DEVELOPERS_RESOURCE
						+ File.separatorChar + apiDeveloperName
						+ File.separatorChar
						+ ResourceTypes.DEVELOPERAPPS_RESOURCE
						+ File.separatorChar + developerAppName + File.separatorChar
						+ ResourceTypes.DEVELOPERAPPKEYS_RESOURCE;

				File[] developerAppKeyFiles = FileUtil.readFiles(
						apigeeImportConfig.getExportDir(), NULL_VALUE,
						folderName, true);
				if (developerAppKeyFiles != null) {
					for (File devAppKeyFile : developerAppKeyFiles) {
						String devAppKeyName = devAppKeyFile.getName();						
						int keyPos = devAppKeyName.lastIndexOf(".");
						if (keyPos != -1) {
							devAppKeyName = devAppKeyName.substring(0, keyPos);
						}
						String developerAppKeyDetails = FileUtil
								.readFile(devAppKeyFile.getAbsolutePath());
						String url = getDeveloperAppKeyImportURL(
								apiDeveloperName, developerAppName);
						int developerAppKeyStatus = developerAppAPIClient
								.createDeveloperAppKey(url,
										developerAppKeyDetails);			
						log.debug("Created Developer AppKey "
								+ devAppKeyFile.getName() + " with status "
								+ developerAppKeyStatus);
						addProductsForDeveloperAppKeys(apiDeveloperName, developerAppName, devAppKeyName, developerAppKeyDetails);
					}
				}
			}
		}
		log.info("Completed Processing Import Developers App Keys ");
	}
	
	/**
	 * This method imports the defined developer app keys from an Apigee
	 * Organization and writes to a folder as defined in the property file.
	 * @throws ParseException 
	 * 
	 * @see application.properties file to configure.
	 */
	@SuppressWarnings("unchecked")
	public void addProductsForDeveloperAppKeys(String apiDeveloperName, String developerAppName, String devAppKeyName, String developerAppKeyDetails) throws ParseException {
		
		String keyUrl = getDeveloperAppKeyURL(apiDeveloperName, developerAppName, devAppKeyName);
				
		JSONParser parser = new JSONParser();
		Object obj;
		obj = parser.parse(developerAppKeyDetails);
		JSONObject jsonObject = (JSONObject) obj;
		
		JSONObject result = new JSONObject();
        JSONArray attribList = (JSONArray) jsonObject.get("attributes");
        JSONArray productsList = new JSONArray();

        JSONArray products = (JSONArray) jsonObject.get("apiProducts");
        Iterator<JSONObject> iterator = products.iterator();
        while (iterator.hasNext()) {
        	JSONObject prodObj = (JSONObject) iterator.next();
            String prodName = (String) prodObj.get("apiproduct");
            productsList.add(prodName);            
        }
       
        result.put("attributes", attribList);
        result.put("apiProducts", productsList);
        
        String jsonResult = result.toJSONString();
		
		int updateStatus = developerAppAPIClient
				.updateDeveloperAppKey(keyUrl,
						jsonResult);
		log.debug("Added Products to Developer AppKey "
				+ devAppKeyName + " with status "
				+ updateStatus);
						

	}

	
}
