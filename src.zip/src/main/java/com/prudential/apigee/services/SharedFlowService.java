package com.prudential.apigee.services;

import java.io.File;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prudential.apigee.integration.SharedFlowAPIClient;
import com.prudential.apigee.util.FileUtil;
import com.prudential.apigee.util.ResourceTypes;

@Service
public class SharedFlowService extends AbstractBaseService {

	private static final Logger log = LoggerFactory
			.getLogger(ExportService.class);

	@Autowired
	private SharedFlowAPIClient sharedFlowAPIClient;

	/**
	 * This method builds the apigee sharedFlow URL to invoke based on
	 * environment and sharedFlowName being sent.
	 * 
	 * @return - String API path of the sharedFlow url.
	 */
	private String getSharedFlowExportURL() {
		return apigeeExportConfig.getExportURL() + URL_PATH
				+ ResourceTypes.SHAREDFLOWS_RESOURCE;
	}

	/**
	 * This method builds the apigee sharedFlow URL to invoke based on
	 * environment and sharedFlowName being sent.
	 * 
	 * @return - String API path of the sharedFlow url.
	 */
	private String getSharedFlowImportURL() {
		return apigeeImportConfig.getImportURL() + URL_PATH
				+ ResourceTypes.SHAREDFLOWS_RESOURCE;
	}

	/**
	 * This method builds the apigee sharedFlow URL to invoke based on
	 * environment and sharedFlowName being sent.
	 * 
	 * @return - String API path of the sharedFlow url.
	 */
	private String getSharedFlowDeploymentURL(String env) {
		return apigeeImportConfig.getImportURL() + "/environments/" + env
				+ URL_PATH + ResourceTypes.SHAREDFLOWS_RESOURCE;
	}

	/**
	 * This method export the defined sharedFlows from an Apigee Organization
	 * and writes to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void exportSharedFlows() {
		String url = getSharedFlowExportURL();
		String sharedFlowsList = sharedFlowAPIClient.getAllSharedFlows(url);
		List<Object> resources = jsonParser.parseList(sharedFlowsList);
		for (Object sharedFlow : resources) {
			String sharedFlowName = sharedFlow.toString().replace("\"", "")
					.trim();
			String sharedFlowDetails = sharedFlowAPIClient.getSharedFlow(url,
					sharedFlowName);
			FileUtil.writeFile(apigeeExportConfig.getExportDir(), NULL_VALUE,
					ResourceTypes.SHAREDFLOWS_RESOURCE, sharedFlowName,
					sharedFlowDetails, true);
			exportSharedFlowBundle(sharedFlowName, sharedFlowDetails);
		}
		log.info("Completed Processing Export SharedFlows for ");
	}

	/**
	 * This method export the defined sharedFlows from an Apigee Organization
	 * and writes to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	@SuppressWarnings("unchecked")
	public void exportSharedFlowBundle(String sharedFlowName,
			String sharedFlowDetails) {
		String url = getSharedFlowExportURL();
		Map<String, Object> resourceMap = jsonParser
				.parseMap(sharedFlowDetails);
		List<Object> revisionList = (List<Object>) resourceMap.get("revision");
		for (Object sharedflowRevision : revisionList) {
			String revision = sharedflowRevision.toString().replace("\"", "")
					.trim();
			byte[] sharedFlowBundle = sharedFlowAPIClient
					.getSharedFlowRevision(url, sharedFlowName, revision);
			FileUtil.writeFile(apigeeExportConfig.getExportDir(), NULL_VALUE,
					ResourceTypes.SHAREDFLOWS_RESOURCE, sharedFlowName + "_"
							+ revision, sharedFlowBundle, false);
			exportSharedFlowDeployments(sharedFlowName, revision);
		}
	}

	/**
	 * This method export the defined sharedFlows from an Apigee Organization
	 * and writes to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void exportSharedFlowDeployments(String sharedFlowName,
			String revision) {
		String url = getSharedFlowExportURL();
		String sharedFlowDeployments = sharedFlowAPIClient
				.getSharedFlowDeployments(url, sharedFlowName, revision);
		String fileName = sharedFlowName + "_" + revision;
		String sharedFolder = ResourceTypes.SHAREDFLOWS_RESOURCE
				+ File.separatorChar + "deployments";
		FileUtil.writeFile(apigeeExportConfig.getExportDir(), NULL_VALUE,
				sharedFolder, fileName, sharedFlowDeployments, true);
		log.info("Completed Processing Export SharedFlows for "
				+ sharedFlowName + " with revision " + revision);
	}

	/**
	 * This method returns the last deployed revision of a shared flow .
	 * 
	 * @see application.properties file to configure.
	 */
	@SuppressWarnings("unchecked")
	public String getSharedFlowRevision(String url, String sharedFlowName) {

		String sharedFlowDetails = sharedFlowAPIClient.getSharedFlow(url,
				sharedFlowName);
		
		String lastRevision = null;
		Map<String, Object> resourceMap = jsonParser
				.parseMap(sharedFlowDetails);
		List<Object> revisionList = (List<Object>) resourceMap.get("revision");
		for (Object sharedflowRevision : revisionList) {
			lastRevision = sharedflowRevision.toString().replace("\"", "")
					.trim();
			log.info(" SharedFlowDetails are " + lastRevision);
		}		
		
		return lastRevision;

	}

	/**
	 * This method export the defined sharedFlows from an Apigee Organization
	 * and writes to a folder as defined in the property file.
	 * 
	 * @see application.properties file to configure.
	 */
	public void importSharedFlows() {
		String url = getSharedFlowImportURL();
		File[] sharedflowFiles = FileUtil.readFiles(
				apigeeImportConfig.getExportDir(), NULL_VALUE,
				ResourceTypes.SHAREDFLOWS_RESOURCE, false);
		for (File sharedFlowFile : sharedflowFiles) {
			String sharedFlowName = sharedFlowFile.getName();
			int pos = sharedFlowName.lastIndexOf("_");			
			if (pos != -1) {
				sharedFlowName = sharedFlowName.substring(0, pos);
			}
			int sharedFlowStatus = sharedFlowAPIClient.createSharedFlow(url,
					sharedFlowName, sharedFlowFile);

			String importedRevision = getSharedFlowRevision(url, sharedFlowName);		

			log.info("Created Sharedflow " + sharedFlowName + " with status "
					+ sharedFlowStatus + " and revision " + importedRevision);
			
			deploySharedFlow(sharedFlowFile.getName().substring(0, sharedFlowFile.getName().indexOf(".")), importedRevision);
		}
		log.info("Completed Processing Import SharedFlows ");

		/*
		 * boolean toDeploy = apigeeImportConfig.isToDeploy();
		 * log.info(" deployment is " + toDeploy); if (toDeploy) {
		 * deploySharedFlows(); }
		 */
	}

	/**
	 * This method deploy the defined sharedFlows into an Apigee Organization
	 * 
	 * @see application.properties file to configure.
	 */
	@SuppressWarnings("unchecked")
	public void deploySharedFlows() {

		String sharedFolder = ResourceTypes.SHAREDFLOWS_RESOURCE
				+ File.separatorChar + "deployments";
		File[] sharedflowFiles = FileUtil.readFiles(
				apigeeImportConfig.getExportDir(), NULL_VALUE, sharedFolder,
				true);
		for (File sharedFlowFile : sharedflowFiles) {
			String sharedFlowName = sharedFlowFile.getName();
			int pos = sharedFlowName.lastIndexOf("_");
			if (pos != -1) {
				sharedFlowName = sharedFlowName.substring(0, pos);
			}
			String sharedFlowDetails = FileUtil.readFile(sharedFlowFile
					.getAbsolutePath());
			Map<String, Object> resourceMap = jsonParser
					.parseMap(sharedFlowDetails);
			List<Object> envList = (List<Object>) resourceMap
					.get("environment");

			Long revision = (Long) resourceMap.get("name");
			log.info(revision.toString());

			for (Object env : envList) {
				String envDetails = env.toString().replace("\"", "").trim();
				if (!envDetails.isEmpty()) {
					Map<String, Object> envMap = jsonParser
							.parseMap(envDetails);
					String envName = (String) envMap.get("name");
					String url = getSharedFlowDeploymentURL(envName);

					String sharedFlowStatus = sharedFlowAPIClient
							.deploySharedFlowRevision(url, sharedFlowName,
									revision.toString());
					log.info("Created Sharedflow " + sharedFlowName
							+ " with status " + sharedFlowStatus);
				}
			}
			log.info("Completed Processing Deployment SharedFlows ");
		}
	}

	/**
	 * This method deploy the defined sharedFlows into an Apigee Organization
	 * 
	 * @see application.properties file to configure.
	 */
	@SuppressWarnings("unchecked")
	public void deploySharedFlow(String sharedFlowFileName,
			String importedRevision) {

		String sharedFlowFilePath = apigeeImportConfig.getExportDir() + File.separatorChar + ResourceTypes.SHAREDFLOWS_RESOURCE
				+ File.separatorChar + "deployments" + File.separatorChar
				+ sharedFlowFileName + ".json";
		String sharedFlowName = sharedFlowFileName;

		int pos = sharedFlowName.lastIndexOf("_");
		if (pos != -1) {
			sharedFlowName = sharedFlowName.substring(0, pos);
		}
		String sharedFlowDetails = FileUtil.readFile(sharedFlowFilePath);

		Map<String, Object> resourceMap = jsonParser
				.parseMap(sharedFlowDetails);

		List<Object> envList = (List<Object>) resourceMap.get("environment");

		String revision = (String)resourceMap.get("name");
		if (!revision.equals(importedRevision)) {
			revision = importedRevision;
		}

		for (Object env : envList) {
			String envDetails = env.toString().replace("\"", "").trim();
			if (!envDetails.isEmpty()) {
				Map<String, Object> envMap = jsonParser.parseMap(envDetails);
				String envName = (String) envMap.get("name");
				String url = getSharedFlowDeploymentURL(envName);

				String sharedFlowStatus = sharedFlowAPIClient
						.deploySharedFlowRevision(url, sharedFlowName,
								revision.toString());
				log.info("Created Sharedflow " + sharedFlowName
						+ " with status " + sharedFlowStatus);
			}
		}
		log.info("Deployment Completed for SharedFlow " + sharedFlowFileName + " with revision " + importedRevision);
	}

}
