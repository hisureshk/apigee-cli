package com.prudential.apigee.services;

public interface ImportService {

	public void importResources(String environment);

	public void importResources();

}
