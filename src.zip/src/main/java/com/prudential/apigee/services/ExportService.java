package com.prudential.apigee.services;


public interface ExportService {
	
	public void exportResources(String environment);
	
	public void exportResources();

}
