package com.prudential.apigee.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prudential.apigee.util.ResourceTypes;

@Service
public class ExportServiceImpl extends AbstractBaseService  implements ExportService {

	@Autowired
	CacheService cacheService;

	@Autowired
	TargetServerService targetServerService;
	
	@Autowired
	ReferenceService referenceService;

	@Autowired
	FlowHookService flowHookService;

	@Autowired
	SharedFlowService sharedFlowService;

	@Autowired
	APIProxyService apiproxyService;

	@Autowired
	ProductService productService;

	@Autowired
	KeyValueMapService apigeeKVM;

	@Autowired
	DeveloperService apigeeDevelopers;

	private static final Logger log = LoggerFactory
			.getLogger(ExportService.class);
	
	/**
	 * This method exports Apigee resources from active Apigee Org to a folder.
	 */
	public void exportResources() {
		beanConfig.setExport(true);
		List<String> types = apigeeExportConfig.getFromResource();
		if(types.size() == 0) {
			log.warn("No \"from.resource\" property is set in the application.properties file " + apigeeExportConfig.getFromResource());
			return;
		}		
		log.debug("Exporting resources using " + apigeeExportConfig.toString());	
		types.parallelStream().forEach(type -> processResource(type));			
	}
	
	public void processResource(String type){
		switch (type) {
			case ResourceTypes.CACHE_RESOURCE:
				cacheService.exportCaches();
				break;
			case ResourceTypes.KVM_RESOURCE:
				apigeeKVM.exportKeyValueMaps();
				break;
			case ResourceTypes.TARGETSERVERS_RESOURCE:
				targetServerService.exportTargetServers();
				break;
			case ResourceTypes.REFERENCES_RESOURCE:
				referenceService.exportReferences();
				break;				
			case ResourceTypes.FLOWHOOKS_RESOURCE:
				flowHookService.exportFlowHooks();
				break;
			case ResourceTypes.SHAREDFLOWS_RESOURCE:
				sharedFlowService.exportSharedFlows();
				break;
			case ResourceTypes.APIPROXY_RESOURCE:
				apiproxyService.exportAPIProxies();
				break;
			case ResourceTypes.APIPRODUCTS_RESOURCE:
				productService.exportProducts();
				break;
			case ResourceTypes.DEVELOPERS_RESOURCE:
				apigeeDevelopers.exportDevelopers();
				break;
			default:
				log.error("Unsupported Resource specified in the application.properites file "
						+ apigeeExportConfig.getFromResource());
				break;
		}
	}

	@Override
	public void exportResources(String environment) {
		// TODO Auto-generated method stub
		
	}
	
}
