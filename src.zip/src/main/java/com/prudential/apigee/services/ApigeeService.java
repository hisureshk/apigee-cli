package com.prudential.apigee.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ApigeeService {

	private static final Logger log = LoggerFactory
			.getLogger(ApigeeService.class);

	@Autowired
	private ExportService apigeeExportService;
	
	@Autowired
	private ImportService apigeeImportService;


	public void exportResources() {
		long startTime = System.currentTimeMillis();
		log.info("Begin Exporting Resources ....");
		apigeeExportService.exportResources();
		long endTime = System.currentTimeMillis();
		log.info("End Exporting Resources ...." + (endTime-startTime) / 1000 + "seconds");
	}	
	
	
	public void importResources() {		
		long startTime = System.currentTimeMillis();
		log.info("Begin Importing Resources ....");
		apigeeImportService.importResources();
		long endTime = System.currentTimeMillis();
		log.info("End Importing Resources ...." + (endTime-startTime) / 1000 + "seconds");		
	}
	
}
