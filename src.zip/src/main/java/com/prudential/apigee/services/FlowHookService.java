package com.prudential.apigee.services;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prudential.apigee.integration.FlowHookAPIClient;
import com.prudential.apigee.util.FileUtil;
import com.prudential.apigee.util.ResourceTypes;

@Service
public class FlowHookService extends AbstractBaseService {

	private static final Logger log = LoggerFactory
			.getLogger(FlowHookService.class);
	
	private static final String[] flowhooks = {"PreProxyFlowHook", "PreTargetFlowHook", "PostTargetFlowHook", "PostProxyFlowHook"}; 
		
	@Autowired
	private FlowHookAPIClient flowhookAPIClient;
	
	
	/**
	 * This method builds the apigee flowhook URL to invoke based on environment and flowhookName being sent.
	 * @param env - Apigee Environment where flowhook will be managed. 
	 * @param flowhookName - Name of the flowhook. 
	 * @return - String API path of the flowhook url.
	 */
	private String getFlowHookExportURL(String env) {
		return apigeeExportConfig.getExportURL(env) + URL_PATH + ResourceTypes.FLOWHOOKS_RESOURCE;
	}
	
	
	/**
	 * This method builds the apigee flowhook URL to invoke based on environment and flowhookName being sent.
	 * @param env - Apigee Environment where flowhook will be managed. 
	 * @param flowhookName - Name of the flowhook. 
	 * @return - String API path of the flowhook url.
	 */
	private String getFlowHookImportURL(String env, String flowHookName) {
			return apigeeImportConfig.getImportURL(env) + URL_PATH + ResourceTypes.FLOWHOOKS_RESOURCE + URL_PATH + flowHookName;
	}
	
	
	
	/**
	 * This method export the defined flowhooks from an Apigee Organization and writes to a folder as defined in the property file.
	 * @see application.properties file to configure.
	 */
	public void exportFlowHooks() {
		List<String> environments = apigeeExportConfig.getFromEnv();
		if(environments.size() == 0) {
			log.error("No \"to.env\" property is set in the application.properties file " + apigeeExportConfig.getFromEnv());
			return;
		}		
		log.debug("Importing resources from " + apigeeExportConfig.getFromEnv());		

		for (String env : environments) {		
			if (env != null && !env.trim().equals("")) {
				exportFlowHooks(env);
			} else {
				log.warn("Blank Environment is specified in the application.properties");
			}
		}
		/*if(types.size() == 0) {
			List<String> environments = getEnvironments();
			for (String envn : environments) {				
				exportFlowHooks(envn);
			}
		}*/
	}
	
	/**
	 * This method export the flowhook details from an Apigee Organization and writes to a file from a given environment.
	 * @param environment - The Apigee environment from which flowhook needs to be export.
	 */
	public void exportFlowHooks(final String environment){
		log.info("Processing Export FlowHooks for " + environment);
		String url = getFlowHookExportURL(environment);		
		List<String> resources = Arrays.asList(flowhooks);
		for (String flowhook : resources) {
			String flowhookName = flowhook.toString();
			String flowhookDetails = flowhookAPIClient.getFlowHook(url, flowhookName);
			FileUtil.writeFile(apigeeExportConfig.getExportDir(), environment, ResourceTypes.FLOWHOOKS_RESOURCE, flowhookName, flowhookDetails, true);			
		}
		log.info("Completed Processing Export FlowHooks for " + environment);
	}
	
	
	/**
	 * This method export the defined flowhooks from an Apigee Organization and writes to a folder as defined in the property file.
	 * @see application.properties file to configure.
	 */
	public void importFlowHooks() {
		List<String> environments = apigeeImportConfig.getToEnv();
		if(environments.size() == 0) {
			log.error("No \"to.env\" property is set in the application.properties file " + apigeeImportConfig.getToEnv());
			return;
		}		
		log.debug("Importing resources from " + apigeeImportConfig.getToEnv());		

		for (String env : environments) {		
			if (env != null && !env.trim().equals("")) {
				importFlowHooks(env);
			} else {
				log.warn("Blank Environment is specified in the application.properties");
			}
		}
		/*
		List<String> environments = getEnvironments();
			for (String envn : environments) {				
				importFlowHooks(envn);
			}
		}*/
	}

	/**
	 * This method export the flowhook details from an Apigee Organization and writes to a file from a given environment.
	 * @param environment - The Apigee environment from which flowhook needs to be export.
	 */
	public void importFlowHooks(final String environment){		
		File[] flowHookFiles = FileUtil.readFiles(apigeeImportConfig.getExportDir(), environment, ResourceTypes.FLOWHOOKS_RESOURCE, true);
		for (File cFile : flowHookFiles) {
			String flowHookName = cFile.getName();
			int pos = flowHookName.lastIndexOf(".");
			if (pos != -1) {
				flowHookName = flowHookName.substring(0, pos);
			}			
			String flowhookDetails = FileUtil.readFile(cFile.getAbsolutePath());
			String url = getFlowHookImportURL(environment, flowHookName);
			int flowhookStatus = flowhookAPIClient.createFlowHook(url, flowhookDetails);
			log.info("CreatedFlowHook " + flowHookName + " in an environment " + environment + " with status " + flowhookStatus);
		}
		log.info("Completed Processing ImportFlowHooks for " + environment);
	}
	
}
