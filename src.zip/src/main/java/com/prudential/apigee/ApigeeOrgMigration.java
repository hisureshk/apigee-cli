package com.prudential.apigee;

import static java.lang.System.exit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Mono;

import com.prudential.apigee.services.ApigeeService;

@SpringBootApplication
public class ApigeeOrgMigration implements CommandLineRunner {
	
	@Autowired
	private ApigeeService apigeeService;
	
	@Autowired
	private WebClient.Builder webClientBuilder;
	
	
	private WebClient webClient;


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//SpringApplication.run(ResourceGroupMigration.class, args);
        SpringApplication app = new SpringApplication(ApigeeOrgMigration.class);
		app.setBannerMode(Banner.Mode.OFF);
		app.run(args);
	}
	
		
    @Override    
    public void run(String... args) throws Exception {
    	apigeeService.exportResources();
    	apigeeService.importResources();
        exit(0);
    }

}
