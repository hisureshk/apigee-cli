package com.prudential.apigee.util;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.security.cert.CertificateException;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.springframework.http.client.SimpleClientHttpRequestFactory;

public class SimpleHTTPClientFactory extends SimpleClientHttpRequestFactory {

	private final HostnameVerifier verifier;

	public SimpleHTTPClientFactory(HostnameVerifier verifier) {
		this.verifier = verifier;
		this.setBufferRequestBody(false); //TODO understand
	}

	@Override
	protected void prepareConnection(HttpURLConnection connection,
			String httpMethod) throws IOException {
		if (connection instanceof HttpsURLConnection) {
			((HttpsURLConnection) connection).setHostnameVerifier(verifier);
			((HttpsURLConnection) connection)
					.setSSLSocketFactory(trustSelfSignedSSL()
							.getSocketFactory());
		}
		super.prepareConnection(connection, httpMethod);
	}
	
	public SSLContext trustSelfSignedSSL() {
		try {
			SSLContext ctx = SSLContext.getInstance("TLS");
			X509TrustManager tm = new X509TrustManager() {

				@Override
				public void checkClientTrusted(
						java.security.cert.X509Certificate[] xcs, String string)
						throws CertificateException {
				}

				@Override
				public void checkServerTrusted(
						java.security.cert.X509Certificate[] xcs, String string)
						throws CertificateException {
				}

				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}
			};
			ctx.init(null, new TrustManager[] { tm }, null);
			SSLContext.setDefault(ctx);
			return ctx;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

}
