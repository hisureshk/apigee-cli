package com.prudential.apigee.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FileUtil {

	private static final Logger log = LoggerFactory.getLogger(FileUtil.class);

	public static void writeFile(String exportDir, String env, String resource, String resourceName,
			Object content, boolean isJson) {
		String fileName = null;
		byte[] strToBytes = null;
		FileOutputStream outputStream = null;
		File fileDir = null;
		try {
			if(env != null)
				fileDir = new File(exportDir + File.separatorChar + env + File.separatorChar + resource);
			else {
				fileDir = new File(exportDir + File.separatorChar + resource);
			}
			fileDir.mkdirs();
			if(isJson){
				fileName = fileDir.getAbsolutePath() + File.separatorChar + resourceName + ".json";
				strToBytes = content.toString().getBytes();
			} else {
				fileName = fileDir.getAbsolutePath() + File.separatorChar + resourceName + ".zip";
				strToBytes = (byte[])content;
			}		
			outputStream = new FileOutputStream(fileName);			
			outputStream.write(strToBytes);			
			log.info("Successfully Written Object to File...");
		} catch (IOException e) {
			log.error(e.getCause().toString());
		} finally {
			clean(outputStream);
		}
	}
	
	
	public static void writeBinaryFile(String exportDir, String env, String resource, String resourceName,
			byte[] content, boolean isJson) {
		String fileName = null;
		byte[] strToBytes = null;
		FileOutputStream outputStream = null;
		File fileDir = null;
		try {
			if(env != null)
				fileDir = new File(exportDir + File.separatorChar + env + File.separatorChar + resource);
			else {
				fileDir = new File(exportDir + File.separatorChar + resource);
			}
			fileDir.mkdirs();
			if(isJson){
				fileName = fileDir.getAbsolutePath() + File.separatorChar + resourceName + ".json";				
			} else {
				fileName = fileDir.getAbsolutePath() + File.separatorChar + resourceName + ".zip";
			}
			strToBytes = content;
			outputStream = new FileOutputStream(fileName);			
			outputStream.write(strToBytes);			
			log.info("Successfully Written Object to File...");
		} catch (IOException e) {
			log.error(e.getCause().toString());
		} finally {
			clean(outputStream);
		}
	}

	public static void clean(FileOutputStream file) {
		if (file != null) {
			try {
				file.flush();
				file.close();
			} catch (IOException e) {
				log.error(e.getCause().toString());
			}
		}
	}


	public static File[] readFiles(String exportDir, String env, String resource, boolean isJson) {
		File fileDir = null;
		if(env != null)
			fileDir = new File(exportDir + File.separatorChar + env + File.separatorChar + resource);
		else {
			fileDir = new File(exportDir + File.separatorChar + resource);
		}
		File[] listFiles = null;
		if(isJson)
				listFiles = fileDir.listFiles(new ApigeeFileFilter("json"));
		else 
				listFiles = fileDir.listFiles(new ApigeeFileFilter("zip"));
		
		/*//JAVA8 syntax not working in the editor
		 * File[] listFiles = file.listFiles((d, s) -> {
			return s.toLowerCase().endsWith(ext);
		});
		exportDir*/
		if(listFiles == null){
			listFiles = new File[0];
		}
		return listFiles;
	}			
	

	public static String readFile(String cFilePath){
		byte[] encoded = null;
		try {
			encoded = Files.readAllBytes(Paths.get(cFilePath));
		} catch (IOException e) {
			log.error(e.getCause().toString());
		} 
		return new String(encoded, Charset.defaultCharset());
	}
	
	
	public static class ApigeeFileFilter implements FilenameFilter {

		private String ext;

		public ApigeeFileFilter(String ext) {
			this.ext = ext.toLowerCase();
		}

		@Override
		public boolean accept(File dir, String name) {
			return name.toLowerCase().endsWith(ext);
		}

	}
	
}