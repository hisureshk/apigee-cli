package com.prudential.apigee.util;

public interface ResourceTypes {
	
	public static final String CACHE_RESOURCE = "caches";
	
	public static final String TARGETSERVERS_RESOURCE = "targetservers";
	
	public static final String REFERENCES_RESOURCE = "references";

	public static final String FLOWHOOKS_RESOURCE = "flowhooks";
	
	public static final String SHAREDFLOWS_RESOURCE = "sharedflows";	
	
	public static final String APIPROXY_RESOURCE = "apis";
	
	public static final String KVM_RESOURCE = "keyvaluemaps";
	
	public static final String APIPRODUCTS_RESOURCE = "apiproducts";
	
	public static final String DEVELOPERAPPS_RESOURCE = "apps";
	
	public static final String DEVELOPERAPPKEYS_RESOURCE = "keys";
	
	public static final String DEVELOPERS_RESOURCE = "developers";
	
	public static final String APIGEE_ENVIRONMENT = "ALL";
	
}
