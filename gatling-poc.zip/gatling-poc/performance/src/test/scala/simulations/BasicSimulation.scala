package simulations

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._
import io.gatling.core.structure.ScenarioBuilder

class BasicSimulation extends Simulation {

   private val baseUrl = "https://perf-api.corp.pru.co.uk"
   private val basicAuthHeader = "Basic WDZQNVFRWTJ3T1hwRU1ndmZZN0FmRTRaaE1BRlI2SGg6Z3FCMmJJbjJQcncwU1RvZA=="
   private val contentType = "application/json"
      
   private val authUser= "KNULAKsfOGOIbAPEVZMgfnJ7NE2yhm5B"
   private val authPass = "Cdbpg58FavpAea7m"
  
   //val numberOfUsers: Int = System.getProperty("numberOfUsers").toInt   
   //val duration: FiniteDuration = System.getProperty("durationMinutes").toInt.minutes
   //val pause: FiniteDuration = System.getProperty("pauseBetweenRequestsMs").toInt.millisecond
   val maxResponseTimeMs = 1000
   val responseSuccessPercentage = 90
   val duration: FiniteDuration = 5.toInt.minutes 

   private val requestCount = 1
   
    /* Final number of users in the simulation. */
    var finalUserCount = 10
    /* Time period after which the number of users is to reach the final number of users. */
    var userCountRampUpTime : FiniteDuration = (20 seconds)
   
  val httpConf = http
    .baseURL("https://perf-api.corp.pru.co.uk") 
    .acceptHeader("*/*")
	.authorizationHeader(basicAuthHeader)
	.acceptEncodingHeader("gzip, deflate")
    .acceptLanguageHeader("en-US,en;q=0.5")
    .contentTypeHeader(contentType)
      
 	val scn: ScenarioBuilder = scenario("RecordedSimulation")
   		.exec(http("request_0")
     	.post("/communications/sms/v1/outbound?provider=BT")
     	.formParam("""""", """""")
     	//.headers(headers_0)
     	.body(ElFileBody("sms.json"))
     	//.basicAuth(authUser, authPass)
     	.check(status.is(200))
     	.check(jsonPath("$.result").is("success"))
     	)
    
        /*
        private val rampUpTime: FiniteDuration = 10.seconds
 
		setUp(
	    	scn.inject(rampUsers(Constants.numberOfUsers) over rampUpTime),
	    	scn.inject(atOnceUsers(Constants.numberOfUsers))
		)
	    .protocols(httpConf)
	    .pauses(constantPauses)
	    .maxDuration(Constants.duration)
	    .assertions(
	        global.responseTime.max.lessThan(Constants.responseTimeMs),
	        global.successfulRequests.percent
	            .greaterThan(Constants.responseSuccessPercentage)
	    )
	    .throttle(reachRps(100) in rampUpTime, holdFor(Constants.duration))
	    */
    
       //setUp(scn.inject(atOnceUsers(requestCount))).protocols(httpConf)
       
         setUp(
            //scn.inject(rampUsers(finalUserCount).over(userCountRampUpTime))
            //scn.inject(atOnceUsers(finalUserCount))
            scn.inject(constantUsersPerSec(finalUserCount) during (duration))
        )
        .protocols(httpConf))
        .assertions(
        	global.responseTime.mean.lt(maxResponseTimeMs),
      		global.successfulRequests.percent.gt(responseSuccessPercentage)
      	)
              
}