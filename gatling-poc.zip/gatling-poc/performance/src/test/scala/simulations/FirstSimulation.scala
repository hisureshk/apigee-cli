package simulations
 
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder.toActionBuilder
import scala.concurrent.duration._
 
/**
  * Example Gatling load test that sends one HTTP GET requests to a URL.
  * Note that the request is redirected and this causes the request count to become two.
  * Run this simulation with:
  * mvn -Dgatling.simulation.name=HttpSimulation1 gatling:execute
  *
  * @author Ivan Krizsan
  */
class FirstSimulation extends Simulation {
	private var contentType = "application/json"
   
   	private var authUser= "KNULAKsfOGOIbAPEVZMgfnJ7NE2yhm5B"
   	private var authPass = "Cdbpg58FavpAea7m"
  
   	//var numberOfUsers: Int = System.getProperty("numberOfUsers").toInt   
   	//var duration: FiniteDuration = System.getProperty("durationMinutes").toInt.minutes
   	//var pause: FiniteDuration = System.getProperty("pauseBetweenRequestsMs").toInt.millisecond
   	var responseTimeMs = 500
   	var responseSuccessPercentage = 99

   	private var requestCount = 1
  
    /* Base URL of requests sent in scenario 1. */
    var scenarioBaseURL = "https://perf-api.corp.pru.co.uk"
    /* Additional request path appended after the base URL in scenario. */
    var scenario1RequestPath = "communications/sms/v1/outbound?provider=BT"
    /* Final number of users in the simulation. */
    var finalUserCount = 25
    /* Time period after which the number of users is to reach the final number of users. */
    var userCountRampUpTime : FiniteDuration = (60 seconds)

    /* Place for arbitrary Scala code that is to be executed before the simulation begins. */
    before {
        println("***** My simulation is about to begin! *****")
    }
 
    /* Place for arbitrary Scala code that is to be executed after the simulation has ended. */
    after {
        println("***** My simulation has ended! ******")
    }
 
    /*
     * A HTTP protocol builder is used to specify common properties of request(s) to be sent,
     * for instance the base URL, HTTP headers that are to be enclosed with all requests etc.
     */
    val theHttpProtocolBuilder = http
        .baseURL("https://perf-api.corp.pru.co.uk")
 
    /*
     * A scenario consists of one or more requests. For instance logging into a e-commerce
     * website, placing an order and then logging out.
     * One simulation can contain many scenarios.
     */
    /* Scenario1 is a name that describes the scenario. */
    val theScenarioBuilder = scenario("Scenario1")
        .exec(
            /* myRequest1 is a name that describes the request. */
            http("myRequest1")
                .get("/")
        )
 
    /*
     * Define the load simulation.
     * Here we can specify how many users we want to simulate, if the number of users is to increase
     * gradually or if all the simulated users are to start sending requests at once etc.
     * We also specify the HTTP protocol builder to be used by the load simulation.
     */
    setUp(
        theScenarioBuilder.inject(atOnceUsers(1))
    ).protocols(theHttpProtocolBuilder)
}