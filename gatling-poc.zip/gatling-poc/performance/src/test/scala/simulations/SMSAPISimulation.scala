package simulations

import io.gatling.core.Predef._
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.http.Predef._
import io.gatling.http.protocol.HttpProtocolBuilder
import io.gatling.http.request.builder.HttpRequestBuilder.toActionBuilder

import scala.concurrent.duration._

/**
  * Abstract Gatling simulation class that specifies properties common to multiple Gatling simulations.
  * Certain simulation parameters have been extracted to class variables which allows for subclasses
  * to modify certain behaviour of the basic simulation by setting new values of these variables.
  *
  */
class SMSAPISimulation extends Simulation {

   	private var contentType = "application/json"
   
   	private var authUser= "KNULAKsfOGOIbAPEVZMgfnJ7NE2yhm5B"
   	private var authPass = "Cdbpg58FavpAea7m"
  
   	//var numberOfUsers: Int = System.getProperty("numberOfUsers").toInt   
   	//var duration: FiniteDuration = System.getProperty("durationMinutes").toInt.minutes
   	//var pause: FiniteDuration = System.getProperty("pauseBetweenRequestsMs").toInt.millisecond
   	var responseTimeMs = 500
   	var responseSuccessPercentage = 99

   	private var requestCount = 1
  
    /* Base URL of requests sent in scenario 1. */
    var scenarioBaseURL = "https://perf-api.corp.pru.co.uk"
    /* Additional request path appended after the base URL in scenario. */
    var scenario1RequestPath = "communications/sms/v1/outbound?provider=BT"
    /* Final number of users in the simulation. */
    var finalUserCount = 25
    /* Time period after which the number of users is to reach the final number of users. */
    var userCountRampUpTime : FiniteDuration = (60 seconds)

    /*
     * Performs initialization of the simulation before it is executed.
     * Initialization must be performed this way in order to allow for subclasses to
     * modify instance variables and for those modifications to affect the resulting
     * simulation configuration.
     */
    before {
        doSetUp()
    }

    /**
      * Creates the HTTP protocol builder used in the simulation.
      */
    def createHttpProtocolBuilder(): HttpProtocolBuilder = {
    
        val httpProtocolBuilder = http
            .baseURL(scenarioBaseURL)
            .acceptHeader("*/*")
            .acceptEncodingHeader("gzip, deflate")
            .acceptLanguageHeader("en-US,en;q=0.5")
            .contentTypeHeader(contentType)            
            .userAgentHeader("Gatling")
        httpProtocolBuilder

    }

    /**
      * Creates the scenario builder used in the simulation.
      */
    def createScenarioBuilder(): ScenarioBuilder = {
    
        val scenarioBuilder = scenario("PerformanceSimulation")
            .exec(
                http("perf_request")
                    .post("/" + scenario1RequestPath)
                    .formParam("""""", """""")
                    .body(ElFileBody("sms.json"))
                    .basicAuth(authUser, authPass)
                    .check(status.is(200))
                    .check(jsonPath("$.result").is("success"))
            )
        scenarioBuilder
    }

    /**
      * Performs setup of the simulation.
      */
    def doSetUp(): Unit = {
        val theScenarioBuilder = createScenarioBuilder()
        val theHttpProtocolBuilder = createHttpProtocolBuilder()

        setUp(
            theScenarioBuilder.inject(rampUsers(finalUserCount).over(userCountRampUpTime))
        ).protocols(theHttpProtocolBuilder)
    }
}