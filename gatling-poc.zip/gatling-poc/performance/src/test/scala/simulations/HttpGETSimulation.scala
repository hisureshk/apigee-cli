package simulations

import common.HttpSimulationBaseClass

import scala.concurrent.duration._

/**
  * Example Gatling load test that is based on an abstract base class.
  * Run this simulation with:
  * mvn -Dgatling.simulation.name=HttpSimulation8 gatling:execute
  *
  * @author Ivan Krizsan
  */
class HttpGETSimulation extends HttpSimulationBaseClass {
    scenario1BaseURL = "https://perf-api.corp.pru.co.uk"
    scenario1RequestPath = ""
    finalUserCount = 4
    userCountRampUpTime = (5 seconds)
}